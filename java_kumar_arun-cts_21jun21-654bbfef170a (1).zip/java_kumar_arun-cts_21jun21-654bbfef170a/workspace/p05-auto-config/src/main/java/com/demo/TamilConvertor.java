package com.demo;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import com.demo.api.MessageConvertor;

@Component
@Primary
public class TamilConvertor implements MessageConvertor {

	@Override
	public void translate(String message) {
		System.out.println("This message is in tamil language: "+message);
	}
	
}
