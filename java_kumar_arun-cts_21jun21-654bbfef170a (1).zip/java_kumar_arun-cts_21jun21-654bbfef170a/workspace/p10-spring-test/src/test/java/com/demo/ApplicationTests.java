package com.demo;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.demo.entities.Movie;
import com.demo.repositories.MovieRepository;
import com.demo.services.MovieService;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

@SpringBootTest
class ApplicationTests {

	@Autowired
	MovieService service;

	@MockBean // MovieService should not use repository
	MovieRepository repository;

	@Test
	void testJunit() {
		Assertions.assertEquals(5, 5);
		Assertions.assertSame(5, 5);
		Assertions.assertTrue(15 > 5);
		Assertions.assertFalse(15 < 5);
	}


	@Test
	public void shouldGetAllMovies(){

		List<Movie> dummyMovies = Stream.of(
			new Movie("Movie 1", "Director 1", 3.5, 2012),
			new Movie("Movie 2", "Director 2", 4.3, 2015),
			new Movie("Movie 3", "Director 1", 3.9, 2018)
		).collect(Collectors.toList());

		Mockito 
			.when(repository.findAll()) 
			.thenReturn(dummyMovies);


		List<Movie> movies = service.getAllMovies();

		System.out.println(movies);
		Assertions.assertEquals(3, movies.size());

	}


	@Test
	public void shouldSaveMovie(){

		Movie movie1 = new Movie("Movie 3", "Director 1", 3.9, 2018);
		// Movie movie2 = new Movie("Movie 3", "Director 1", 3.9, 2018);

		Mockito 
			.when(repository.save(movie1)) 
			.thenReturn(new Movie("someid", "Movie 3", "Director 1", 3.9, 2018));

		Movie movie = service.saveMovie(movie1);

		Assertions.assertEquals("someid", movie.getId());
	}

	@Test
	public void shouldFindMovieById() throws Exception{

		Mockito 
			.when(repository.findById("someid")) 
			.thenReturn(Optional.of(new Movie("someid", "Movie 3", "Director 1", 3.9, 2018)));

		Movie movie = service.getMovieById("someid");

		Assertions.assertEquals("someid", movie.getId());
	}
	

	@Test
	public void shouldNotFindMovieById() throws Exception{

		Mockito 
			.when(repository.findById("someid")) 
			.thenReturn(Optional.empty());

		Assertions.assertThrows(Exception.class, ()->{service.getMovieById("someid");});

	}
	



}
