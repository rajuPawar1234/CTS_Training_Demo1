package com.demo.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.PostConstruct;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.models.Book;

@RestController
@RequestMapping("/books")
public class BookController {

	private Map<Integer, Book> books = new HashMap<Integer, Book>();
	private static int num = 0;
	
	@PostConstruct
	public void afterInit(){
		books.put(++num, new Book(num, "This is my book", "Me", 45.9));
		books.put(++num, new Book(num, "This is your book", "You", 99));
		books.put(++num, new Book(num, "This is our book", "We", 125));
		books.put(++num, new Book(num, "This is his book", "He", 61));
		books.put(++num, new Book(num, "This is her book", "She", 29));
	}
	
	@GetMapping(value="", produces= {
			MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	})
	public List<Book> findAllBooks(){
		List<Book> list = new ArrayList<Book>();
		Set<Integer> keys = books.keySet();
		for(int key:keys) {
			list.add(books.get(key));
		}
		return list;
	}
	
	@GetMapping("/{id}")
	public Book findBookById(@PathVariable int id){
		return books.get(id);
	}
	
	@PostMapping(value="", consumes={
			MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	}, produces= {
			MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE
	})
	public Book createNewBook(@RequestBody Book book) {
		System.out.println("In request: "+book);
		// db will create id
		book.setId(++num);
		books.put(num, book);
		return book;
	}
	
	@PutMapping("/{id}")
	public ResponseEntity<Book> modifyBook(@PathVariable int id, @RequestBody Book book) {
		System.out.println("Book to update: "+book);
		Book dbBook = books.get(id);
		if(dbBook != null) {
			book.setId(id);
			books.put(id, book);
			
			return ResponseEntity.status(HttpStatus.OK).body(book);
		} else {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(null);
		}
	}
	
	@DeleteMapping("/{id}")
	public Book removeBook(@PathVariable int id) {
		System.out.println("Delete book");
		return books.remove(id);
	}
	
}
