package com.demo.controllers;

import java.time.LocalDate;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

//@Controller
@RestController // = @Controller + @ResponseBody
public class UserController {

	@GetMapping("/greet")
//	@ResponseBody
	public String greet() {
		return "Welcome user";
	}
	
	@GetMapping("/today")
	public LocalDate currentDate() {
		return LocalDate.now();
	}
	
}
