package com.demo.repositories;

import java.util.List;

import com.demo.entities.Movie;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MovieRepository extends JpaRepository<Movie, String> {
    
    // findAllMovies
    // findMovieById
    // findMovieByTitle
    // deleteMovieById
    // deleteMovie 
    // updateMovie
    // saveMovie 

    public List<Movie> findByDirector(String director);

    // @Query("")
    // public List<Movie> filterByRating(double rating);

}
