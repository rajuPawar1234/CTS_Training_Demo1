package com.demo.controllers;

import java.util.List;

import com.demo.entities.Book;
import com.demo.exceptions.BookNotFoundException;
import com.demo.services.BookService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/books")
public class BookController {

    @Autowired
    BookService service;

    @GetMapping("")
    @ApiOperation(value="Fetch all books", notes="No argument method")
    public List<Book> getAllBooks(){
        return service.getAllBooks();
    }

    @GetMapping("/{id}")
    @ApiOperation(value="Fetch all books", notes="Number type id is used as parameter")
    public Book findById(@ApiParam(value="id is required") @PathVariable int id) throws BookNotFoundException{
        return service.findById(id);
    }
    
    @PostMapping("")
    public Book createNewBook(@RequestBody Book book){
        return service.createNewBook(book);
    }
    
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable int id,@RequestBody Book book) throws BookNotFoundException {
        return service.updateBook(id, book);
    }
    
    @DeleteMapping("/{id}")
    public boolean deleteBook(int id){
        service.deleteBook(id);

        return true;
    }

    @GetMapping("/abc")
    public List<Book> FilterData(@RequestHeader("author") String author){
        System.out.println("Author:++++++++++++++++++++++++++++++");
        System.out.println("Author: "+author);
        return service.getAllBooks();
    }
    
}
