package com.demo.config;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.models.Path;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

@Configuration
public class SwaggerConfig {

	@Bean
	public Docket mySwaggerConfig() {
		return new Docket(DocumentationType.SWAGGER_2)
		.select()// object to configure
//		.paths(PathSelectors.ant("/api/**"))
		.apis(RequestHandlerSelectors.basePackage("com.demo"))
		.build()
		.apiInfo(metadata())
		;
	}
	
	private ApiInfo metadata() {
        return new ApiInfoBuilder()
        		.title("This is my Book application")
        		.description("This application desc")
        		.license("My custom license")
        		.version("1.3.9")
        		.contact(new Contact("IIHT", "demo.com", "iiht@iiht.com"))
        		.build();
        		
//                "My REST API", //title
//                "Some custom description of API.", //description
//                "Version 1.0", //version
//                "Terms of service", //terms of service URL
//                new Contact("Bhanuka Dissanayake", "www.example.com", "myeaddress@company.com"),
//                "License of API", "API license URL", Collections.emptyList() // contact info
    }
	
}
