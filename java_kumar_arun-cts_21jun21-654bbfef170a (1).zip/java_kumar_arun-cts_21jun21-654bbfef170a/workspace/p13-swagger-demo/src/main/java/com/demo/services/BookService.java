package com.demo.services;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import com.demo.entities.Book;
import com.demo.exceptions.BookNotFoundException;
import com.demo.repositories.BookRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {

    @Autowired
    BookRepository repository;
    
    public List<Book> getAllBooks(){
        return repository.findAll();
    }

    public Book findById(int id) throws BookNotFoundException{
        Optional<Book> optional = repository.findById(id);
        if(optional.isPresent()){
            return optional.get();
        } else {
            throw new BookNotFoundException(id+" is not found in db");
        }
    }
    
    public Book createNewBook(Book book){
        return repository.save(book);
    }
    
    public Book updateBook(int id, Book book) throws BookNotFoundException {
        if(repository.existsById(id)){
            return repository.save(book);
        } else {
            throw new BookNotFoundException(id+" is not found in db, update not possible");
        }
    }
    
    public void deleteBook(int id){
        repository.deleteById(id);
    }


    public void dummyExceptionRaised() throws SQLException {
            repository.count(); // sqlException
    }
    
}
