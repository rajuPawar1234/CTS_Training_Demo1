package com.demo;

import com.demo.client.MyRestClient;
import com.demo.entities.Book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {

	@Autowired
	MyRestClient client;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		System.out.println("Before save: ");
		System.out.println("Size: "+client.fetchBooks().size());
		System.out.println("POST a book");
		System.out.println("Saved Book: "+client.saveBook(new Book("963", "This is comic book", "Raj", 2)));
		System.out.println("+++++++++++++++++");
		System.out.println("GET all books");
		System.out.println("Size: "+client.fetchBooks().size());
		System.out.println("List: "+client.fetchBooks());
		System.out.println("Request with headers");
		System.out.println("++++++++++++++++++++++");
		// System.out.println("List: "+client.reqWithHeader("title", "qwertyuiop"));
		System.out.println("List: "+client.reqWithHeader("author", "jfhgfhf"));
		
	}

}
