package com.demo.config;

import com.demo.entities.CustomMessage;
import com.demo.exceptions.BookNotFoundException;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;


// cross cutting concern
@ControllerAdvice
public class CustomControllerAdvice {
    
    // incoming -> 500
    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<CustomMessage> handleException(Exception e){
        return ResponseEntity.status(200).body(new CustomMessage(204, e.getMessage()));
    }

}
