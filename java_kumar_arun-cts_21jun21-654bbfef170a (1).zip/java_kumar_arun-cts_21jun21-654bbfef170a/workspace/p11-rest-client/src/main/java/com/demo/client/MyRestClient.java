package com.demo.client;

import java.util.List;

import com.demo.entities.Book;

import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class MyRestClient {
    
    private static String HOST = "http://localhost:8080/api/v1/books"; 

    private RestTemplate restTemplate = new RestTemplate();

    public List<Book> fetchBooks(){
        // send request to HOST
        // wait for response 

        ResponseEntity<List<Book>> response = restTemplate.exchange(
            HOST, 
            HttpMethod.GET, 
            null, 
            new ParameterizedTypeReference<List<Book>>(){}
        );

        return response.getBody();
    }

    public Book saveBook(Book book){

        HttpEntity<Book> entity = new HttpEntity<Book>(book);

        ResponseEntity<Book> response = restTemplate.exchange(
            HOST, 
            HttpMethod.POST, 
            entity, 
            new ParameterizedTypeReference<Book>(){}
        );

        return response.getBody();
    }



    public List<Book> reqWithHeader(String headerKey, String headerValue){

        HttpHeaders headers = new HttpHeaders();
        headers.set(headerKey, headerValue);
        // headers.set("Authorization", "token");

        HttpEntity<Book> entity = new HttpEntity<Book>(null, headers);

        ResponseEntity<List<Book>> response = restTemplate.exchange(
            HOST+"/abc", 
            HttpMethod.GET, 
            entity, 
            new ParameterizedTypeReference<List<Book>>(){}
        );

        return response.getBody();
    }


}
