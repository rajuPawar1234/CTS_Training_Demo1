package com.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
public class Application implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	@Override
	public void run(String... args) throws Exception {
//		String pwd = "demo@123";
//		String encodedPwd = passwordEncoder.encode(pwd);
//		System.out.println(encodedPwd);
//		
//		System.out.println(passwordEncoder.matches("demo@123", encodedPwd));
//		System.out.println(passwordEncoder.matches("demo#123", encodedPwd));
	}

	
}
