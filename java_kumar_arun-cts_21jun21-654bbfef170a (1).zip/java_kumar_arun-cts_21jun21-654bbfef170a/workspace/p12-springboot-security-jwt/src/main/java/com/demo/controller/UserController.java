package com.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/users")
public class UserController {
	
	@GetMapping("/greet")
	public String greet() {
		return "Welcome friend";
	}

	@GetMapping("/greet/{friend}")
	public String greet(@PathVariable String friend) {
		return "Welcome "+friend;
	}

}
