package com.demo.controllers;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.demo.exceptions.CustomException;
import com.demo.model.ErrorResponse;

@ControllerAdvice
public class AdviceController {

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<ErrorResponse> handleCustomException(CustomException e){
		ErrorResponse response = new ErrorResponse();
		response.setStatus(500);
		response.setMessage("some error occurred");
		
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
}
