package com.demo.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.demo.exceptions.CustomException;

@Service
public class DemoService {

	public boolean saveRecord(String name) throws CustomException{
		try {
			name.charAt(5);
			return false;
		} catch(NullPointerException e) {
			throw new CustomException("Invalid data", e);
		}
	}
	
}
