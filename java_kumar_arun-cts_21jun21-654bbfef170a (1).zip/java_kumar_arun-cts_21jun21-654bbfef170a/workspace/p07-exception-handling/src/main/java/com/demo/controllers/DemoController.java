package com.demo.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.exceptions.CustomException;
import com.demo.services.DemoService;

@RestController
public class DemoController {
	
	@Autowired
	DemoService service;

	@GetMapping("/demo")
	public String getDemoPage() {
		System.out.println("in demo url");
		return "welcome";
	}
	
	@GetMapping("/save")
	public boolean saveNewRecord() throws CustomException {
		return service.saveRecord(null);
	}
	
	
}
