package com.demo.repositories;

import java.util.List;

import com.demo.entities.Movie;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface MovieRepository extends MongoRepository<Movie, String> {
    
    // findAllMovies
    // findMovieById
    // findMovieByTitle
    // deleteMovieById
    // deleteMovie 
    // updateMovie
    // saveMovie 

    public List<Movie> findByDirector(String director);

    // @Query("")
    // public List<Movie> filterByRating(double rating);

}
