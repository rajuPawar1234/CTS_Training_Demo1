package com.demo.controllers;

import java.util.List;

import com.demo.entities.Movie;
import com.demo.services.MovieService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/movies")
public class MovieController {

    @Autowired
    private MovieService service;
    
    @GetMapping("")
    public List<Movie> getAllMovies(){
        System.out.println("finding all movies");
        return service.getAllMovies();
    }

    @GetMapping("/{id}")
    public Movie getMovieById(@PathVariable String id){
        System.out.println("finding movie by id: "+id);
        return service.getMovieById(id);
    }

    @PostMapping("")
    public Movie saveMovie(@RequestBody Movie movie){
        System.out.println("saving new movie: "+movie);
        return service.saveMovie(movie);
    }

    @GetMapping("/search/director/{director}")
    public List<Movie> getMoviesBydirector(@PathVariable String director){
        System.out.println("finding movie by director: "+director);
        return service.getMoviesBydirector(director);
    }


}