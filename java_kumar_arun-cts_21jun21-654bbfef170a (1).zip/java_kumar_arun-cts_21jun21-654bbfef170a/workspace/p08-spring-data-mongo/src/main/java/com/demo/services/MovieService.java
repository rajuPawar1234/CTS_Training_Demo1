package com.demo.services;

import java.util.List;
import java.util.Optional;

import com.demo.entities.Movie;
import com.demo.repositories.MovieRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MovieService {

    @Autowired
    private MovieRepository repository;
    
    public List<Movie> getAllMovies(){
        return repository.findAll();
    }

    public Movie getMovieById(String id){
        Optional<Movie> optional = repository.findById(id);
        // return optional.orElse(null);

        if(optional.isPresent()){
            return optional.get();
        } else {
            return null;
        }
    }

    public Movie saveMovie(Movie movie){
        return repository.save(movie);
    }

    public List<Movie> getMoviesBydirector(String director){
        return repository.findByDirector(director);
    }
}
