package com.demo.controllers;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class DemoController {

	@GetMapping("/demo")
	public String getDemoPage() {
		System.out.println("in demo url");
		return "welcome";
	}
	
	@GetMapping("/demo2")
	public String getDemoPage2() {
		System.out.println("in demo2 url");
		throw new NullPointerException();
	}
	
	@PostMapping("/demo3")
	public String getDemoPage3() {
		System.out.println("in demo3 url");
		return "welcome";
	}
	
//	@RequestMapping("/error")
//	public String handleError(HttpServletRequest req) {
//		if(status==404)
//			return 404.html
//					
//					
//	}
	
}
