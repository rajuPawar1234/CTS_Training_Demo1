package com.demo.api;

public interface MessageConvertor {

	public void translate(String message);
	
}
