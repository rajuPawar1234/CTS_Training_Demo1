### Some ground rules for the training/sessions  
- All the participants, please be on mute mode so that other participants will not get disturbed during the session  
- Dont try to write code with me. Just follow the instructions during demonstrations. You will get enough time to practice  
- If you have any doubt or question please type it on chat window or unmute your self and ask, and I will try to answer it as soon as possible  
- All the code material that I am going to type during demonstrations in session will be available on this link: https://bitbucket.org/java_kumar_arun/cts_21jun21


