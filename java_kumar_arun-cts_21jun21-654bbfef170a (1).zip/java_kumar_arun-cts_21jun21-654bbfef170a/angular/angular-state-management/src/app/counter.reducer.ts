import { createReducer, on } from '@ngrx/store';
import { Action } from 'rxjs/internal/scheduler/Action';
import { increment , decrement, reset } from './counter.actions'

export const initialState = 0;

const _counterReducer = createReducer(
    initialState,
    on(increment, (state, action) => state + action.payload.num),
    on(decrement, (state) => state - 1),
    on(reset, (state, action) => action.payload.num)
)

export function counterReducer(state, action) {
    return _counterReducer(state, action)
}