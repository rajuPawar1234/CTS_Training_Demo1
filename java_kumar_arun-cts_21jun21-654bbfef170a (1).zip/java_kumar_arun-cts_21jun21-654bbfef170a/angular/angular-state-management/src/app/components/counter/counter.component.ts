import { Component } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { increment, decrement, reset } from 'src/app/counter.actions';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.scss']
})
export class CounterComponent {

  count$:Observable<number>;
  constructor(private store: Store<{count : number}>) { 
    this.count$ = store.pipe(select('count'));
  }

  increment(){
    this.store.dispatch(increment({
      payload: {num: 5}
    }))
  }
  decrement(){
    this.store.dispatch(decrement())
  }
  reset(num:number=0){
    console.log("Num: "+num);

    this.store.dispatch(reset({
      payload: { num: num }
      }));
  }

}
