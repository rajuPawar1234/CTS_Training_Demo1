import { Component } from "@angular/core";

class Employee{
    // name:string;
    // age:number;
    // constructor(name, age){
    //     this.name = name;
    //     this.age = age;
    // }
    constructor(public name:string, public age:number){}
}

@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    styleUrls: ["app.component.css"]
})
export class AppComponent {
    flag:boolean = false;

    emps:Employee[] = [
        {name: "Mark", age: 54},
        new Employee("Miley", 34),
        new Employee("Tom", 25)
    ]
    
    toggle(){
        this.flag = !this.flag;
    }

}