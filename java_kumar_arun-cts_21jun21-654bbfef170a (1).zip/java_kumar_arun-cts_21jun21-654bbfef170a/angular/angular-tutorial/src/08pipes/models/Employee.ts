export class Employee{
    constructor(public name:string, public age:number){}
}
