import { Component } from "@angular/core";
import { Employee } from "./models/Employee";


@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    styleUrls: ["app.component.css"]
})
export class AppComponent {
    // today:Date = new Date();
    today:number = Date.now();

    name:string = "aNGulAr"

    emps:Employee[] = [
        {name: "Mark", age: 54},
        new Employee("Miley", 34),
        new Employee("Tom", 25)
    ]

    obj = {
        name: "miley",
        age: 35,
        
        contact: {
            email: "miley@gmail.com",
            phones: [96584,254155],
            address: {
                city: "delhi"
            }
        }
    }
    
}