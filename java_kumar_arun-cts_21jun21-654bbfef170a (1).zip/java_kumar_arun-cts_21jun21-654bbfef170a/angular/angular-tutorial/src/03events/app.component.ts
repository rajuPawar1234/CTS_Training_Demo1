import { Component } from "@angular/core";

@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    // selector: "abc"
    styleUrls: ["app.component.css"]
})
export class AppComponent {
    count:number = 33;
    constructor() {
        console.log("This is app component")
        this.increase()
    }


    increase(){
        this.count++;
    }
    decrease(){
        this.count--;
    }

    reset(n:number = 0){
        this.count = n;
    }
}