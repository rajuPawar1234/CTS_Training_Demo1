import { enableProdMode } from '@angular/core';
import { environment } from './environments/environment';
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";


// import { AppModule } from './01basic/app.module';
// import { AppModule } from './02components/app.module';
// import { AppModule } from './03events/app.module';
// import { AppModule } from './04routing/app.module';
// import { AppModule } from './05form/app.module';
// import { AppModule } from './06directives/app.module';
// import { AppModule } from './07directives/app.module';
// import { AppModule } from './08pipes/app.module';
// import { AppModule } from './09pipes_custom/app.module';
// import { AppModule } from './10ajax/app.module';
// import { AppModule } from './11app/app.module';
// import { AppModule } from './12exception/app.module';
import { AppModule } from './13logger/app.module';


if (environment.production) {
  enableProdMode();
}

platformBrowserDynamic().bootstrapModule(AppModule)
