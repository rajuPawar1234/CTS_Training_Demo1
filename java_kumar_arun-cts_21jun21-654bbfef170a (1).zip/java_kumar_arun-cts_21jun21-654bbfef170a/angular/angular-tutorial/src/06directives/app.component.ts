import { Component } from "@angular/core";

@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    styleUrls: ["app.component.css"]
})
export class AppComponent {
    flag:boolean = false;
    currentClass:string = "border";
    myColor = "white";
    myStyle = {
        "color": "red"
    }

    toggle(){
        this.flag = !this.flag;
        this.setClass();
    }

    setClass(){
        if(this.flag){
            this.currentClass = "radius";
        } else {
            this.currentClass = "border";
        }
    }
}