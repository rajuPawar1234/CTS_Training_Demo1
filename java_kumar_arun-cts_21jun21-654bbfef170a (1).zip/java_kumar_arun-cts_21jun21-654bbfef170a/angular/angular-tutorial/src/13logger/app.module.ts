import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { LoggerModule, NgxLoggerLevel } from "ngx-logger";
import { AppComponent } from "./app.component";

@NgModule({
    imports: [
        BrowserModule,
        HttpClientModule,
        LoggerModule.forRoot({
            level: NgxLoggerLevel.DEBUG,
            serverLogLevel: NgxLoggerLevel.ERROR,
            serverLoggingUrl: "http://localhost:3000/errors"
            // colorScheme: ['purple', 'teal', 'gray', 'gray', 'red', 'red', 'red']
        })
    ],
    bootstrap: [AppComponent],
    declarations: [AppComponent]
})
export class AppModule { }