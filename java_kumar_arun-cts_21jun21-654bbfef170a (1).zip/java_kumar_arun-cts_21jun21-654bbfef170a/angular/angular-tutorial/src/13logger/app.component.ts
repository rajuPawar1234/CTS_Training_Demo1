import { Component } from "@angular/core";
import { User } from "./models/User";
import { HttpClient } from "@angular/common/http";
import { NGXLogger } from "ngx-logger";
import { MyLoggerMonitor } from "./logger/logger-monitor";



@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    styleUrls: ["app.component.css"]
})
export class AppComponent {

    constructor(private httpClient: HttpClient, private logger: NGXLogger) {
        this.logger.registerMonitor(new MyLoggerMonitor());
    }

    signup() {
        let url = "http://localhost:3000/users123"
        // data -> 
        let user = new User("admin", "admin@gmail.com", "admin@123");
        // send request
        this.httpClient.post(url, user)
            .subscribe(res => {
// console.log(res)
                this.logger.debug(res);
            }, err => {
                this.logger.error("This is error while registration");
                this.logger.error(err);
            })
    }
}