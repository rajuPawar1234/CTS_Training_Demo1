import { Component } from "@angular/core";
import { User } from "./models/User";
import { HttpClient } from "@angular/common/http";



@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    styleUrls: ["app.component.css"]
})
export class AppComponent {
    
    constructor(private httpClient:HttpClient){}
    
    signup(){
        let url = "http://localhost:3000/users"
        // data -> 
        let user = new User("admin", "admin@gmail.com", "admin@123");
        // send request
        this.httpClient.post(url, user)
        .subscribe(res=>{
            console.log(res);
        })
    }
}