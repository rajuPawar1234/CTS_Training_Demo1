import { Component } from "@angular/core";
import { User } from "./models/User";
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import { UserService } from "./services/user.service";



@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    styleUrls: ["app.component.css"]
})
export class AppComponent {

    ajaxErr = {
        isError: false,
        message: ""
    }
    
    constructor(private userService:UserService){}
    
    signup(){
        let user = new User("demo", "demo@gmail.com", "demo@123");

        this.userService.register(user)
        .subscribe(res=>{

            this.ajaxErr.isError = false;
            this.ajaxErr.message = "";


            console.log(res);
        }/* , (err:any)=> {
            console.log("Error is caught in component");
            this.ajaxErr.isError = true;
            this.ajaxErr.message = err.message;
          } */)
    }

    
}