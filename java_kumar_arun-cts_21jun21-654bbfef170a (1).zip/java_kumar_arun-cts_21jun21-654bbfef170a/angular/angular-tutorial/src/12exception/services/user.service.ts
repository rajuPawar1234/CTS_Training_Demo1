import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { User } from '../models/User';

@Injectable()
export class UserService {
  HOST:string = "http://localhost:3000/users123"

  constructor(private httpClient:HttpClient) { }

  register(user:User){
    return this.httpClient.post(this.HOST, user)
    // .pipe(this.handleError)
  }

  login(user:User){
    return this.httpClient.post(this.HOST, user)
    // .pipe(this.handleError)
  }


  handleError(err:any) {
    console.log("Error is caught:");
    console.log(err instanceof HttpErrorResponse);

    return throwError(err);
  }
}
