import { HttpClientModule } from "@angular/common/http";
import { ErrorHandler, NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AppComponent } from "./app.component";
import { MyErrorHandler } from "./exception-handler/my-error-handler";
import { UserService } from "./services/user.service";

@NgModule({
    imports: [BrowserModule, HttpClientModule],
    bootstrap: [AppComponent],
    declarations: [AppComponent],
    providers: [
        UserService,
        {provide: ErrorHandler, useClass: MyErrorHandler}
    ]
})
export class AppModule { }