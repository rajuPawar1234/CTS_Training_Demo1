import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from "./../../../../environments/environment"

@Injectable()
export class FlightService {


  HOST:string = "http://localhost:3000/flights"

  constructor(private http:HttpClient) { 
    console.log(environment)
  }

  getAllFlights(){
    return this.http.get(this.HOST);
  }
}
