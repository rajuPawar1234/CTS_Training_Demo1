import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent } from './list/list.component';
import { RouterModule } from '@angular/router';
import { routes } from './flight.routing';
import { HttpClientModule } from '@angular/common/http';
import { FlightService } from './services/flight.service';



@NgModule({
  declarations: [ListComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    HttpClientModule
  ],
  providers: [FlightService]
})
export class FlightModule { }
