import { Component, OnInit } from '@angular/core';
import { FlightService } from '../services/flight.service';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {

  flights = [];
  constructor(private flightService:FlightService) { }

  ngOnInit(): void {
    // load data
    this.flightService.getAllFlights()
    .subscribe((res:any)=>{
      this.flights = res;
    },(err:any)=>{
      console.log(err);
    })
  }

}
