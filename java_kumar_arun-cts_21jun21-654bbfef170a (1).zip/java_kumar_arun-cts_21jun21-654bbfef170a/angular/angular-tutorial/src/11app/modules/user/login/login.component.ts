import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm:FormGroup;

  constructor(private userService:UserService, private router:Router) {
    this.loginForm = new FormGroup({
      "email": new FormControl(
        "demo@gmail.com", 
        [
          Validators.required,
          Validators.pattern("[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?")
        ]
        ),
      "password": new FormControl("123", Validators.required)
    });
  }

  ngOnInit(): void {
  }

  login(){
    console.log(this.loginForm)
    console.log(this.loginForm.value);
    console.log(this.loginForm.valid);

    if(this.loginForm.valid){
      console.log("send user data to server");
      this.userService.getLogin(this.loginForm.value)
      .subscribe(res=>{

        let response = res[0];
        // based on requirement -> success user -> res[0]
        console.log(response);
        if(response.success){
          this.loginForm.reset();
          localStorage.setItem("isValid", "true");
          // navigate
          this.router.navigate(['/', 'flight', 'list']);
        } else {
          console.log("invalid user, login failed")
        }
      })
    }
  }

}
