import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable()
export class UserService {
  HOST: string = "http://localhost:3000/";
  constructor(private http: HttpClient) { }

  getLogin(user) {
    // can not consume user
    console.log("User: ");
    console.log(user);

    let headers = new HttpHeaders();
    headers.append('demohead', "abdlkfsdlfkjsldf");
    headers.append('Content-Type', "application/xml");
    headers.append('Accept', "application/xml");

    return this.http.get(this.HOST + "login", {
      headers: headers
    });

  }

  createAccount(user) {
    return this.http.post(this.HOST + "users", user)
  }


}
