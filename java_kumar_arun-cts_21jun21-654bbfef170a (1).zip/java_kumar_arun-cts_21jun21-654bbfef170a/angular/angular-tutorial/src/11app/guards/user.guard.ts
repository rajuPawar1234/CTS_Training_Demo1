import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import jwt_decode from "jwt-decode";

@Injectable({
  providedIn: 'root'
})
export class UserGuard implements CanActivate {



  constructor(private router:Router){}

  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): boolean {

      // let token = localStorage.getItem("token");
      // https://jwt.io
      let token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY5ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
      var decodedToken = jwt_decode(token);

      console.log(decodedToken)// name and expiry and ...

      if(!!decodedToken['name']){
        return true;
      } else {
        this.router.navigate(["/", "user", "login"]);
        // return false;
      }

  }
  
}
