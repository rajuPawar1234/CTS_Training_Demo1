import { Routes } from "@angular/router";
import { AboutComponent } from "./components/about/about.component";
import { HistoryComponent } from "./components/history/history.component";
import { HomeComponent } from "./components/home/home.component";
import { PaymentComponent } from "./components/payment/payment.component";
import { UserGuard } from "./guards/user.guard";

export const routes:Routes = [
    { path: "home", component: HomeComponent },
    { path: "payment", component: PaymentComponent },
    { path: "history", component: HistoryComponent },
    { path: "about", component: AboutComponent },
    
    { path: "user", loadChildren: ()=>import('./modules/user/user.module').then(module => module.UserModule)},
    { 
        path: "flight", 
        loadChildren: 
            ()=>import('./modules/flight/flight.module')
            .then(
                module => module.FlightModule
            ), 
        canActivate: [UserGuard]
    },

    // { path: "**", pathMatch: "full", component: ErrorPageComponent  }
    { path: "**", pathMatch: "full", redirectTo: "home"  }
]


// export default RouterModule.forRoot(routes)