import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AppComponent } from "./app.component";
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { HistoryComponent } from './components/history/history.component';
import { PaymentComponent } from './components/payment/payment.component';
import { RouterModule } from "@angular/router";
import { routes } from "./app.routing";


@NgModule({
    imports: [BrowserModule, RouterModule.forRoot(routes)],
    bootstrap: [AppComponent],
    declarations: [AppComponent, HomeComponent, AboutComponent, HistoryComponent, PaymentComponent]
})
export class AppModule { }