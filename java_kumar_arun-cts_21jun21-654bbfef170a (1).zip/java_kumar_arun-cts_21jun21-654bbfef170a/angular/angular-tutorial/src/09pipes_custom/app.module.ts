import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AppComponent } from "./app.component";
import { CapitalizePipe } from './capitalize.pipe';
import { PowerPipe } from './power.pipe';

@NgModule({
    imports: [BrowserModule],
    bootstrap: [AppComponent],
    declarations: [AppComponent, CapitalizePipe, PowerPipe]
})
export class AppModule { }