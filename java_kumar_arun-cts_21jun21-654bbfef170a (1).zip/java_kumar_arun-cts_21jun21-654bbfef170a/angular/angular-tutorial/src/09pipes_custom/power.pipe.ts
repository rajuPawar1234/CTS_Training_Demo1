import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'power'
})
export class PowerPipe implements PipeTransform {

  transform(num: number, exp:number = 2): number {
    return Math.pow(num, exp);
  }

}
