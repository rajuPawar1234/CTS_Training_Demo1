import { Component } from "@angular/core";

@Component({
    selector: "app-root",
    templateUrl: 'app.component.html',
    // selector: "abc"
    styleUrls: ["app.component.css"]
})
export class AppComponent {
    constructor() {
        console.log("This is app component")
    }
}