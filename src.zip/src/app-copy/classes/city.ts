export class City {
  id: string;
  city: string;
  country: string;
}
