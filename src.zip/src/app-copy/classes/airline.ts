export class Airline {
  id: string;
  name: string;
  description: string;
  phone: string;
  location: string;
}
