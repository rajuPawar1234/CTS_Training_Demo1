export class User{
    constructor(public name:string, public mobile:number, public email:string, public password:string){}
}
