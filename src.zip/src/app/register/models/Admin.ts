export class Admin{
    constructor(public name:string, public email:string){}
}
