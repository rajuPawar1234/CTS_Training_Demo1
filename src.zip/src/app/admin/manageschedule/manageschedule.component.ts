import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CommomserviceService } from 'src/app/commomservice.service';
import { Flights } from 'src/app/Models/Flights';

@Component({
  selector: 'app-manageschedule',
  templateUrl: './manageschedule.component.html',
  styleUrls: ['./manageschedule.component.css']
})
export class ManagescheduleComponent implements OnInit {

  flights : Flights[] = [] ;

  constructor(private http : HttpClient,private service : CommomserviceService) { }

  ngOnInit(): void {
    this.getAllFlights();
  }

  getAllFlights(){
    this.service.getAllFlight().subscribe((res)=>{
      this.flights = res;
    })
  }

}
