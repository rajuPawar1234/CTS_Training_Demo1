import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updateairline',
  templateUrl: './updateairline.component.html',
  styleUrls: ['./updateairline.component.css']
})
export class UpdateairlineComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

}
