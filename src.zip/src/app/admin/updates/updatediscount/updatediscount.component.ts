import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatediscount',
  templateUrl: './updatediscount.component.html',
  styleUrls: ['./updatediscount.component.css']
})
export class UpdatediscountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
