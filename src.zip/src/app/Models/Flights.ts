export class Flights{
    constructor(public airlinename  :string, 
        public airlinecontact:number,
        public airlineaddress: string){}
}