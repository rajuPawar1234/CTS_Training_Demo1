export class Flights{
    constructor(
        public airlineid : number,
        public airlinename  :string, 
        public airlinecontact:number,
        public airlineaddress: string
        ){}
}