export class Passenger {
    constructor(public name: string,public id_proof: string, public date_of_birth: Date,
        public meal_preference: string,
        public meal_included: string   
    ) {

}
}