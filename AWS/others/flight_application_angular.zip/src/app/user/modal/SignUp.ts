
export class UserRegister {
    constructor(public first_name: string, public last_name: string
        , public mobile_number: string,
        public username: string,
        public password: string,
    ) { }
}