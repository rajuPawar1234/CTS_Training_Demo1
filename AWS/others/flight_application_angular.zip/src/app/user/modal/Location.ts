
export class Location{

    constructor(public stateCode:string, public stateName:string){
    }
}