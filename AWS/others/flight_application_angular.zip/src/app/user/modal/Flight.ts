export class Flight {
 constructor(public id: number, public departure_date_time: string, public flight_name: string,
        public flight_number: string,
        public no_of_passenger: string,
        public pnr_no: string) {
    }

}