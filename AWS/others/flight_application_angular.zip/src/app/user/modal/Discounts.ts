
export class Discount{
    constructor(public discount_number: string, public discount_name: string, public price: number){

    }
}