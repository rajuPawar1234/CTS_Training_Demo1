import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'user-footer',
  templateUrl: './user-footer.component.html',
  styleUrls: ['./user-footer.component.css']
})
export class UserFooterComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
