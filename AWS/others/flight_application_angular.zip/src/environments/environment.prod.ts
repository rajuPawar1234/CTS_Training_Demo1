export const environment = {
  production: true,
  HOST: "http://ec2-3-131-157-235.us-east-2.compute.amazonaws.com",
  port: 9090
};
