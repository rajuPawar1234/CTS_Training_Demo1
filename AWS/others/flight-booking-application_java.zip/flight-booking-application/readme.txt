----How to use the complete project----
1.Import the userdump.csv file in DB.
2.Maven module contains eureka server as flight_application_server,
 microservices as admin-application, flight-master-data, user-application and
 zuul api gateway.

3. For master data need to import the location.csv file in flight master database for the flight from location and to location.
4. For starting an application, some flight and discount master data need to import in flight_master_data schema from flight.csv and discount.csv file.

