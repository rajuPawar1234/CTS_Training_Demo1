package com.cts.flight.pojo;

import lombok.Data;

@Data
public class Location {

	private Long id;
	
	private String stateCode;
	
	private String stateName;
	
	
}
