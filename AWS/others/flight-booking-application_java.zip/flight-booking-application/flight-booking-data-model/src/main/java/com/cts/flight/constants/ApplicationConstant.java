//package com.cts.flight.constants;
//
//import org.springframework.beans.factory.annotation.Value;
//
//public class ApplicationConstant {
//
//	
//	@Value("${kafka.server.config}")
//	public String KAFKA_LOCAL_SERVER_CONFIG = "localhost:9092";
//	
//	@Value("${kafka.gorup.id}")
//	public String GROUP_ID_STRING = "group-id-string-1";
//	
//	@Value("${kafka.topi,c.name}")
//	public String TOPIC_NAME = "flight_application";
//	
//	@Value("${kafka.listener.factory}")
//	public String KAFKA_LISTENER_CONTAINER_FACTORY = "kafkaListenerContainerFactory";
//}
//
