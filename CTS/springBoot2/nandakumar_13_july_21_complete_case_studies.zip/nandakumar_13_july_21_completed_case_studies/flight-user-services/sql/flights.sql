-- MySQL dump 10.13  Distrib 8.0.25, for Win64 (x86_64)
--
-- Host: localhost    Database: flights
-- ------------------------------------------------------
-- Server version	8.0.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `flight_booking`
--

DROP TABLE IF EXISTS `flight_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flight_booking` (
  `booking_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `from` bigint unsigned DEFAULT NULL,
  `to` bigint unsigned DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `phone_no` bigint unsigned DEFAULT NULL,
  `no_of_tickets` int unsigned DEFAULT '0',
  `total_amount` double DEFAULT '0',
  `scheduled_id` bigint unsigned DEFAULT NULL,
  `generated_date_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `price_per_tickets` double DEFAULT '0',
  `state` tinyint DEFAULT '1',
  `user_id` bigint unsigned NOT NULL,
  `pnr_number` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`booking_id`),
  KEY `fk_from_location_id_flight_booking` (`from`),
  KEY `fk_to_location_id_flight_booking` (`to`),
  KEY `fk_scheduled_flight_id_flight_booking` (`scheduled_id`),
  KEY `fk_flight_booking_user_fd` (`user_id`),
  CONSTRAINT `fk_flight_booking_user_fd` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_from_location_id_flight_booking` FOREIGN KEY (`from`) REFERENCES `locations` (`id`),
  CONSTRAINT `fk_scheduled_flight_id_flight_booking` FOREIGN KEY (`scheduled_id`) REFERENCES `scheduled_flights` (`scheduled_flight_id`),
  CONSTRAINT `fk_to_location_id_flight_booking` FOREIGN KEY (`to`) REFERENCES `locations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flight_booking`
--

LOCK TABLES `flight_booking` WRITE;
/*!40000 ALTER TABLE `flight_booking` DISABLE KEYS */;
INSERT INTO `flight_booking` VALUES (1,1,2,'nandakumar',9645907762,1,1000,2,'2021-07-06 19:53:14',1000,1,2,'123456'),(2,1,2,'nand',9645,2,2000,2,'2021-07-06 20:23:56',1000,1,2,'112345'),(3,3,4,'Nandhu',789123525,4,20000,3,'2021-07-06 20:50:12',5000,1,2,'863268');
/*!40000 ALTER TABLE `flight_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `location_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `location_code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `location_code_no` bigint unsigned DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Chennai','CHE',1,'Chennai',10,11),(2,'Coimbatore','CBE',2,'Coimbatore',12,13),(3,'Bangalore','BGE',1,'Bangalore',15,11),(4,'Kochi','KHI',1,'Kochi',10,11);
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manage_discounts`
--

DROP TABLE IF EXISTS `manage_discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manage_discounts` (
  `discount_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `discount_name` varchar(100) DEFAULT NULL,
  `discounts_no` varchar(100) DEFAULT NULL,
  `percentage` double DEFAULT '0',
  `amount` double DEFAULT '0',
  `state` tinyint DEFAULT '1',
  `generated_date_time` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`discount_id`),
  KEY `manage_discounts_state_IDX` (`state`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manage_discounts`
--

LOCK TABLES `manage_discounts` WRITE;
/*!40000 ALTER TABLE `manage_discounts` DISABLE KEYS */;
INSERT INTO `manage_discounts` VALUES (1,'dis10','10',10,1000,0,'2021-07-06 00:28:45'),(2,'Dis10','10',10,1001,1,'2021-07-06 00:31:38');
/*!40000 ALTER TABLE `manage_discounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `manage_flights`
--

DROP TABLE IF EXISTS `manage_flights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `manage_flights` (
  `flight_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `flight_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `flight_no` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `number_of_seats` int DEFAULT '1',
  `price` double DEFAULT '0',
  `generated_date_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `state` tinyint DEFAULT '1',
  PRIMARY KEY (`flight_id`),
  KEY `manage_flights_state_IDX` (`state`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `manage_flights`
--

LOCK TABLES `manage_flights` WRITE;
/*!40000 ALTER TABLE `manage_flights` DISABLE KEYS */;
INSERT INTO `manage_flights` VALUES (1,'AirIndia','12345',280,10000,'2021-07-05 23:30:56',1),(2,'AirAsia','13345',380,10600,'2021-07-05 23:45:40',0),(3,'AirAsia1','12244',450,1251,'2021-07-06 00:23:48',0),(4,'Indigo','2345',380,5000,'2021-07-06 20:47:14',1);
/*!40000 ALTER TABLE `manage_flights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `role` varchar(100) NOT NULL,
  `user_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`),
  KEY `role_FK` (`user_id`),
  CONSTRAINT `role_FK` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'ROLE_ADMIN',1),(2,'ROLE_USER',2);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_flights`
--

DROP TABLE IF EXISTS `scheduled_flights`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_flights` (
  `scheduled_flight_id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `flight_id` bigint unsigned DEFAULT NULL,
  `from_location_id` bigint unsigned DEFAULT NULL,
  `to_location_id` bigint unsigned DEFAULT NULL,
  `price_per_tickets` double DEFAULT '0',
  `departure_date` date DEFAULT NULL,
  `departure_time` time DEFAULT NULL,
  `arrival_date` date DEFAULT NULL,
  `arrival_time` time DEFAULT NULL,
  `generated_date_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `state` tinyint DEFAULT '1',
  PRIMARY KEY (`scheduled_flight_id`),
  KEY `fk_form_location_id` (`from_location_id`),
  KEY `fk_to_location_id` (`to_location_id`),
  KEY `scheduled_flights_FK` (`flight_id`),
  CONSTRAINT `fk_form_location_id` FOREIGN KEY (`from_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `fk_to_location_id` FOREIGN KEY (`to_location_id`) REFERENCES `locations` (`id`),
  CONSTRAINT `scheduled_flights_FK` FOREIGN KEY (`flight_id`) REFERENCES `manage_flights` (`flight_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_flights`
--

LOCK TABLES `scheduled_flights` WRITE;
/*!40000 ALTER TABLE `scheduled_flights` DISABLE KEYS */;
INSERT INTO `scheduled_flights` VALUES (1,1,2,4,100,'2021-07-06','15:19:00','2021-07-06','19:19:00','2021-07-06 15:19:57',1),(2,1,1,2,1000,'2021-07-06','16:20:00','2021-07-06','17:20:00','2021-07-06 16:20:47',1),(3,4,3,4,5000,'2021-07-10','02:47:00','2021-07-10','20:48:00','2021-07-06 20:48:23',1);
/*!40000 ALTER TABLE `scheduled_flights` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `email_id` varchar(100) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `active` tinyint DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_id_IDX` (`email_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@gmail.com','$2a$10$nN/y9nYTUm2h3CCFC88CnuJuuGOiAr8UeasKv67w3KPtVoQ9n65fy',1),(2,'user','user@gmail.com','$2a$10$RR0yPNO1cCaTfU1Zdp11muYHf6ON4TeT0Ci9OJSV91/elo0x0ws0i',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-07-07  0:09:35
