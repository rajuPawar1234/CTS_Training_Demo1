package com.flightbooking.exception;

import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.context.request.WebRequest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.flightbooking.model.ErrorResponseBO;

import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class ExceptionHandlerClass {

	@ExceptionHandler(DuplicateKeyException.class)
	public ResponseEntity<ErrorResponseBO> handleTheSqlException(Exception e, WebRequest request) {
		ErrorResponseBO errorResponse = new ErrorResponseBO(HttpStatus.BAD_REQUEST.value(),
				"Email is already taken try again with different email id");
		return ResponseEntity.status(HttpStatus.OK).body(errorResponse);
	}

	@ExceptionHandler(JsonProcessingException.class)
	public ResponseEntity<ErrorResponseBO> handleTheCovertionException(CustomException e, WebRequest request) {
		ErrorResponseBO errorResponse = new ErrorResponseBO(HttpStatus.INTERNAL_SERVER_ERROR.value(),
				"Unable to covert the flight details, please make sure the all details are filed");
		return ResponseEntity.status(HttpStatus.OK).body(errorResponse);
	}

	@ExceptionHandler(CustomException.class)
	public ResponseEntity<ErrorResponseBO> handleTheCommonException(CustomException e, WebRequest request) {
		ErrorResponseBO errorResponse = new ErrorResponseBO(HttpStatus.INTERNAL_SERVER_ERROR.value(), e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(errorResponse);
	}

	@ExceptionHandler(NullPointerException.class)
	public ResponseEntity<ErrorResponseBO> handleTheCommonException(NullPointerException e, WebRequest request) {
		ErrorResponseBO errorResponse = new ErrorResponseBO(HttpStatus.BAD_REQUEST.value(), e.getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(errorResponse);
	}
}
