package com.flightbooking.model;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Time;

import com.fasterxml.jackson.annotation.JsonFormat;

public class BookingFlightsBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6872261186821943183L;
	private Long id;
	private Long scheduledId;
	private Long flightId;
	private String flightName;
	private Long fromLocationId;
	private Long toLocationId;
	private String fromLocationName;
	private String toLocationName;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "IST")
	private Date departureDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "IST")
	private Date returnDate;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd", timezone = "IST")
	private Date arrivalDate;
	private Time departureTime;
	private Time arrivalTime;
	private Double pricePerTickets;
	private Integer totalTickets;
	private Double totalprice;
	private Long phoneNumber;
	private String userName;
	private int state;
	private String status;
	private String pnrNumber;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getScheduledId() {
		return scheduledId;
	}

	public void setScheduledId(Long scheduledId) {
		this.scheduledId = scheduledId;
	}

	public Long getFlightId() {
		return flightId;
	}

	public void setFlightId(Long flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public Long getFromLocationId() {
		return fromLocationId;
	}

	public void setFromLocationId(Long fromLocationId) {
		this.fromLocationId = fromLocationId;
	}

	public Long getToLocationId() {
		return toLocationId;
	}

	public void setToLocationId(Long toLocationId) {
		this.toLocationId = toLocationId;
	}

	public String getFromLocationName() {
		return fromLocationName;
	}

	public void setFromLocationName(String fromLocationName) {
		this.fromLocationName = fromLocationName;
	}

	public String getToLocationName() {
		return toLocationName;
	}

	public void setToLocationName(String toLocationName) {
		this.toLocationName = toLocationName;
	}

	public Date getDepartureDate() {
		return departureDate;
	}

	public void setDepartureDate(Date departureDate) {
		this.departureDate = departureDate;
	}

	public Date getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(Date returnDate) {
		this.returnDate = returnDate;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Time getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}

	public Time getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public Double getPricePerTickets() {
		return pricePerTickets;
	}

	public void setPricePerTickets(Double pricePerTickets) {
		this.pricePerTickets = pricePerTickets;
	}

	public Integer getTotalTickets() {
		return totalTickets;
	}

	public void setTotalTickets(Integer totalTickets) {
		this.totalTickets = totalTickets;
	}

	public Double getTotalprice() {
		return totalprice;
	}

	public void setTotalprice(Double totalprice) {
		this.totalprice = totalprice;
	}

	public Long getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPnrNumber() {
		return pnrNumber;
	}

	public void setPnrNumber(String pnrNumber) {
		this.pnrNumber = pnrNumber;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("BookingFlightsBO [id=");
		builder.append(id);
		builder.append(", scheduledId=");
		builder.append(scheduledId);
		builder.append(", flightId=");
		builder.append(flightId);
		builder.append(", flightName=");
		builder.append(flightName);
		builder.append(", fromLocationId=");
		builder.append(fromLocationId);
		builder.append(", toLocationId=");
		builder.append(toLocationId);
		builder.append(", fromLocationName=");
		builder.append(fromLocationName);
		builder.append(", toLocationName=");
		builder.append(toLocationName);
		builder.append(", departureDate=");
		builder.append(departureDate);
		builder.append(", returnDate=");
		builder.append(returnDate);
		builder.append(", arrivalDate=");
		builder.append(arrivalDate);
		builder.append(", departureTime=");
		builder.append(departureTime);
		builder.append(", arrivalTime=");
		builder.append(arrivalTime);
		builder.append(", pricePerTickets=");
		builder.append(pricePerTickets);
		builder.append(", totalTickets=");
		builder.append(totalTickets);
		builder.append(", totalprice=");
		builder.append(totalprice);
		builder.append(", phoneNumber=");
		builder.append(phoneNumber);
		builder.append(", userName=");
		builder.append(userName);
		builder.append(", state=");
		builder.append(state);
		builder.append(", status=");
		builder.append(status);
		builder.append(", pnrNumber=");
		builder.append(pnrNumber);
		builder.append("]");
		return builder.toString();
	}


	public BookingFlightsBO(Long fromLocationId, Long toLocationId, Date departureDate) {
		super();
		this.fromLocationId = fromLocationId;
		this.toLocationId = toLocationId;
		this.departureDate = departureDate;
	}

	public BookingFlightsBO() {
		// TODO Auto-generated constructor stub
	}

}