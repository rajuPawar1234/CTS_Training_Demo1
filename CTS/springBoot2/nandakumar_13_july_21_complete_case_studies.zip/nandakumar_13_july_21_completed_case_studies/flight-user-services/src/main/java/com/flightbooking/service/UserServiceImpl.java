package com.flightbooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.flightbooking.db.UserRepository;
import com.flightbooking.exception.CustomException;
import com.flightbooking.model.BookingFlightsBO;
import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.UserBO;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository repository;

	@Override
	public List<BookingFlightsBO> getAvailableFlights(BookingFlightsBO search) {

		return repository.getAvailableFlights(search);
	}

	@Override
	public int bookingFlights(BookingFlightsBO search) throws CustomException {

		return repository.bookingFlights(search);
	}

	@Override
	public int cancelBooking(Long id) throws CustomException {

		return repository.cancelBooking(id);
	}

	@Override
	public int signup(UserBO user) {

		return repository.signup(user);
	}

	@Override
	public List<LocationsBO> getLocations() {

		return repository.getLocations();
	}

	@Override
	public List<DiscountsBO> getDiscounts() {

		return repository.getDiscounts();
	}

	@Override
	public List<BookingFlightsBO> getBookedFlights() {
		return repository.getBookedFlights();
	}

}
