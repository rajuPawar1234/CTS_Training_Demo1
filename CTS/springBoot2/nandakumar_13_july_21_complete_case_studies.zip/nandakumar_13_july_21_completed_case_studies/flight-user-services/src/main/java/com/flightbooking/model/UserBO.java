package com.flightbooking.model;

import java.io.Serializable;
import java.sql.Date;

public class UserBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9103782126195272756L;
	private Long userId;
	private String userName;
	private String mailId;
	private String password;
	private Date joiningDate;
	private int isActive;
	private boolean isAdmin;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("UserBO [userId=");
		builder.append(userId);
		builder.append(", userName=");
		builder.append(userName);
		builder.append(", mailId=");
		builder.append(mailId);
		builder.append(", password=");
		builder.append(password);
		builder.append(", joiningDate=");
		builder.append(joiningDate);
		builder.append(", isActive=");
		builder.append(isActive);
		builder.append(", isAdmin=");
		builder.append(isAdmin);
		builder.append("]");
		return builder.toString();
	}

}
