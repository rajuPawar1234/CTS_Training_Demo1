package com.flightbooking.service;

import java.util.List;

import org.springframework.cache.annotation.Cacheable;

import com.flightbooking.exception.CustomException;
import com.flightbooking.model.BookingFlightsBO;
import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.UserBO;

public interface UserService {

	List<BookingFlightsBO> getAvailableFlights(BookingFlightsBO search);

	int bookingFlights(BookingFlightsBO search) throws CustomException;

	int cancelBooking(Long id) throws CustomException;

	int signup(UserBO user);

	@Cacheable(value = "getLocations", unless = "#result==null")
	List<LocationsBO> getLocations();

	List<DiscountsBO> getDiscounts();

	List<BookingFlightsBO> getBookedFlights();

}
