package com.flightbooking.db;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

import com.flightbooking.exception.CustomException;
import com.flightbooking.model.BookingFlightsBO;
import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.UserBO;

@Repository
public class UserRepositoryImpl implements UserRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<BookingFlightsBO> getAvailableFlights(BookingFlightsBO search) {
		String queryForGettingFlightsForBooking = "select sf.scheduled_flight_id,sf.departure_date,sf.departure_time,sf.arrival_time,sf.price_per_tickets,l1.location_name as from_location_name,l2.location_name as to_location_name,sf.from_location_id, sf.to_location_id,mf.flight_id,mf.flight_name from scheduled_flights sf join manage_flights mf on sf.flight_id=mf.flight_id join locations l1 on sf.from_location_id=l1.id join locations l2 on sf.to_location_id=l2.id where sf.departure_date=? and sf.from_location_id=? and sf.to_location_id=? and sf.state=1 and mf.state=1";
		List<BookingFlightsBO> flightsList = jdbcTemplate.query(queryForGettingFlightsForBooking, ps -> {
			ps.setDate(1, search.getDepartureDate());
			ps.setLong(2, search.getFromLocationId());
			ps.setLong(3, search.getToLocationId());
		}, (rs, row) -> {
			BookingFlightsBO flight = new BookingFlightsBO();
			flight.setFlightId(rs.getLong("flight_id"));
			flight.setFlightName(rs.getString("flight_name"));
			flight.setScheduledId(rs.getLong("scheduled_flight_id"));
			flight.setDepartureDate(rs.getDate("departure_date"));
			flight.setDepartureTime(rs.getTime("departure_time"));
			flight.setArrivalTime(rs.getTime("arrival_time"));
			flight.setPricePerTickets(rs.getDouble("price_per_tickets"));
			flight.setFromLocationId(rs.getLong("from_location_id"));
			flight.setFromLocationName(rs.getString("from_location_name"));
			flight.setToLocationId(rs.getLong("to_location_id"));
			flight.setToLocationName(rs.getString("to_location_name"));

			return flight;
		});
		return flightsList;
	}

	@Override
	public int bookingFlights(BookingFlightsBO search) throws CustomException {
		int row = 0;
		final Long userId = this.getUserId();

		if (userId != null) {

			String queryForBookingTickts = "INSERT INTO flight_booking (`from`, `to`, user_name, phone_no, no_of_tickets, total_amount, scheduled_id, price_per_tickets,user_id,pnr_number) VALUES(?, ?, ?, ?, ?, ?, ?, ?,?,LPAD(FLOOR(RAND() * 999999.99), 6, '0'))";

			row = jdbcTemplate.update(queryForBookingTickts, ps -> {
				Double totalAmount = search.getPricePerTickets() * search.getTotalTickets();
				ps.setLong(1, search.getFromLocationId());
				ps.setLong(2, search.getToLocationId());
				ps.setString(3, search.getUserName());
				ps.setLong(4, search.getPhoneNumber());
				ps.setLong(5, search.getTotalTickets());
				ps.setDouble(6, totalAmount);
				ps.setLong(7, search.getScheduledId());
				ps.setDouble(8, search.getPricePerTickets());
				ps.setLong(9, userId);
			});
		} else {
			throw new CustomException("Invalid user, please logout and log-in again");
		}
		return row;
	}

	@Override
	public int cancelBooking(Long id) throws CustomException {
		String queryForCancelBooking = "UPDATE flight_booking SET  state=0 WHERE booking_id=?";
		int row = jdbcTemplate.update(queryForCancelBooking, ps -> {
			ps.setLong(1, id);
		});

		if (row == 0) {
			throw new CustomException("Invalid flight booking id");
		}
		return row;
	}

	@Override
	public int signup(UserBO user) {
		String queryForInsertUser = "INSERT INTO users (name, email_id, password) VALUES(?, ?, ?)";
		int rowFlag = 0;

		rowFlag = jdbcTemplate.update(queryForInsertUser, ps -> {
			ps.setString(1, user.getUserName());
			ps.setString(2, user.getMailId());
			ps.setString(3, new BCryptPasswordEncoder(10).encode(user.getPassword()));
		});

		if (rowFlag > 0) {
			String queryForGettingUserId = "select max(id) as id from users u where email_id=?";

			List<Long> userIdList = jdbcTemplate.query(queryForGettingUserId, ps -> {
				ps.setString(1, user.getMailId());
			}, (rs, row) -> {

				return rs.getLong("id");
			});

			if (userIdList != null && !userIdList.isEmpty() && userIdList.get(0) > 0L) {
				Long userId = userIdList.get(0);
				String queryForInsertRole = "INSERT INTO `role` (`role`, user_id) VALUES('ROLE_USER', ?)";
				rowFlag = jdbcTemplate.update(queryForInsertRole, ps -> {
					ps.setLong(1, userId);
				});

			}
		}
		return rowFlag;
	}

	@Override
	public List<LocationsBO> getLocations() {
		String queryForGettingTheLocations = "SELECT id, location_name, location_code, location_code_no, address, latitude, longitude FROM locations";
		List<LocationsBO> locations = jdbcTemplate.query(queryForGettingTheLocations, (rs, row) -> {
			LocationsBO location = new LocationsBO();
			location.setId(rs.getLong("id"));
			location.setLocationName(rs.getString("location_name"));
			location.setLocationCode(rs.getString("location_code"));
			location.setLocationCodeNo(rs.getInt("location_code_no"));
			location.setAddress(rs.getString("address"));
			location.setLatitude(rs.getDouble("latitude"));
			location.setLongitude(rs.getDouble("longitude"));
			return location;
		});
		return locations;
	}

	@Override
	public List<DiscountsBO> getDiscounts() {
		String queryForGettingDiscounts = "SELECT discount_id, discount_name, discounts_no, percentage, amount FROM manage_discounts where state=1";
		List<DiscountsBO> discountDetails = jdbcTemplate.query(queryForGettingDiscounts, (rs, row) -> {
			DiscountsBO discount = new DiscountsBO();
			discount.setId(rs.getLong("discount_id"));
			discount.setDiscountName(rs.getString("discount_name"));
			discount.setDiscountsNo(rs.getString("discounts_no"));
			discount.setPercentage(rs.getDouble("percentage"));
			discount.setAmount(rs.getDouble("amount"));
			return discount;
		});
		return discountDetails;
	}

	private Long getUserId() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();

		if (auth != null) {
			String userName = auth.getName();

			String queryToGetUserId = "select id as user_id from users where email_id=?";
			List<Long> userIdList = jdbcTemplate.query(queryToGetUserId, ps -> {
				ps.setString(1, userName);
			}, (rs, row) -> {

				return rs.getLong("user_id");
			});

			return !userIdList.isEmpty() && userIdList.get(0) > 0L ? userIdList.get(0) : null;
		}

		return null;
	}

	@Override
	public List<BookingFlightsBO> getBookedFlights() {
		String queryForGettingBookedFlights = "SELECT fb.booking_id, l1.location_name as from_location_name,l2.location_name as to_location_name, fb.user_name, fb.phone_no, fb.no_of_tickets, fb.total_amount, fb.scheduled_id, fb.price_per_tickets,sf.departure_date,sf.departure_time,sf.arrival_date,sf.arrival_time, if(fb.state=0 or sf.state=0 or mf.state=0,'Cancelled','Good') as status, if(fb.state=0 or sf.state=0 or mf.state=0,0,1) as state,fb.pnr_number,mf.flight_name FROM flight_booking fb  join locations l1 on fb.from=l1.id join locations l2 on fb.to =l2.id join scheduled_flights sf on sf.scheduled_flight_id=fb.scheduled_id join manage_flights mf  on sf.flight_id=mf.flight_id where  user_id=? order by sf.departure_date desc";
		Long userId = this.getUserId();

		if (userId != null) {
			List<BookingFlightsBO> bookedFlightsDetails = jdbcTemplate.query(queryForGettingBookedFlights, ps -> {
				ps.setLong(1, userId);
			}, (rs, row) -> {
				BookingFlightsBO flights = new BookingFlightsBO();
				flights.setId(rs.getLong("booking_id"));
				flights.setFromLocationName(rs.getString("from_location_name"));
				flights.setToLocationName(rs.getString("to_location_name"));
				flights.setUserName(rs.getString("user_name"));
				flights.setPhoneNumber(rs.getLong("phone_no"));
				flights.setTotalTickets(rs.getInt("no_of_tickets"));
				flights.setTotalprice(rs.getDouble("total_amount"));
				flights.setScheduledId(rs.getLong("scheduled_id"));
				flights.setPricePerTickets(rs.getDouble("price_per_tickets"));
				flights.setState(rs.getInt("state"));
				flights.setDepartureDate(rs.getDate("departure_date"));
				flights.setDepartureTime(rs.getTime("departure_time"));
				flights.setArrivalDate(rs.getDate("arrival_date"));
				flights.setArrivalTime(rs.getTime("arrival_time"));
				flights.setStatus(rs.getString("status"));
				flights.setPnrNumber(rs.getString("pnr_number"));
				flights.setFlightName(rs.getString("flight_name"));
				return flights;
			});

			return bookedFlightsDetails;
		}
		return null;
	}

}
