package com.flightbooking.dao;

import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {

	/** The logger. */
	Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	private JdbcTemplate jdbcTemplate;

	/**
	 * Find by user login.
	 *
	 * @param username the user name
	 * @return the user details
	 */
	public User findByUserLogin(String username) {

		String query = "SELECT id, name, email_id, password, active FROM users where email_id=? and active=1";
		List<User> user = jdbcTemplate.query(query, ps -> {
			ps.setString(1, username);
		}, (rs, row) -> {
			User retVal = new User(username, rs.getString("password"), getGrantedAuthorities(username));
			return retVal;
		});
		return (user != null && !user.isEmpty() && user.get(0) != null) ? user.get(0) : null;
	}

	/**
	 * Gets the granted authorities.
	 *
	 * @param username the user name
	 * @return the granted authorities
	 */
	public Collection<? extends GrantedAuthority> getGrantedAuthorities(String username) {
		logger.debug("##### Username: " + username);
		String queryForRole = "select r.role from role r join users u on u.id=r.user_id where u.active=1 and u.email_id=?";
		List<GrantedAuthority> authorities = jdbcTemplate.query(queryForRole, ps -> {
			ps.setString(1, username);
		}, (rs, row) -> {
			return new SimpleGrantedAuthority(rs.getString("role"));
		});

		return authorities;
	}

}
