package com.flightbooking.model;

import java.io.Serializable;

public class ErrorResponseBO implements Serializable {

	private static final long serialVersionUID = 7426428657566676956L;
	private int statusCode;
	private String message;
	private Object data;

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ErrorResponseBO [statusCode=");
		builder.append(statusCode);
		builder.append(", message=");
		builder.append(message);
		builder.append(", data=");
		builder.append(data);
		builder.append("]");
		return builder.toString();
	}

	public ErrorResponseBO(int statusCode, String message, Object data) {
		this.statusCode = statusCode;
		this.message = message;
		this.data = data;
	}

	public ErrorResponseBO(int statusCode, String message) {
		this.statusCode = statusCode;
		this.message = message;
	}

	public ErrorResponseBO() {
	}

}
