package com.flightbooking.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.flightbooking.exception.CustomException;
import com.flightbooking.model.BookingFlightsBO;
import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.UserBO;
import com.flightbooking.service.UserService;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
//@RequestMapping("/user")
@CrossOrigin
@Secured("ROLE_USER")
@ApiOperation(value = "User controller which is used to process the user related process", notes = "It is secured for user role")
public class UserFlightBookingController {
	Logger logger = LoggerFactory.getLogger(getClass());
	@Autowired
	private UserService service;

	@PostMapping("/get-flights")
	@ApiOperation(value = "To view all the flights avaliable for an date")
	public List<BookingFlightsBO> getAvailableFlights(
			@ApiParam(value = "The avaliable flights are searched for based on the given conditions") @RequestBody BookingFlightsBO search) {
		logger.debug("*********************" + search);
		return service.getAvailableFlights(search);
	}

	@PostMapping("/flight-booking")
	@ApiOperation(value = "To book the flight by all the details given from user")
	public int bookingFlights(
			@ApiParam(value = "All the details of passenger for booking the flight") @RequestBody BookingFlightsBO search)
			throws CustomException {
		return service.bookingFlights(search);
	}

	@GetMapping("/booked-flights")
	@ApiOperation(value = "To show the booked flights")
	public List<BookingFlightsBO> getBookedFlights() {
		return service.getBookedFlights();
	}

	@PostMapping("/cancel-booking/{id}")
	@ApiOperation(value = "To cancel the already booked flights")
	public int cancelBooking(
			@ApiParam(value = "The previously booked id for cancelling the flight") @PathVariable Long id)
			throws CustomException {
		return service.cancelBooking(id);
	}

	@PostMapping("/signup")
	@ApiOperation(value = "To register a new user")
	public int signup(@RequestBody UserBO user) {
		System.out.println("############################user" + user);
		return service.signup(user);
	}

	@GetMapping("/locations")
	@ApiOperation(value = "To get all the airport locations")
	public List<LocationsBO> getLocations() {
		return service.getLocations();
	}

	@GetMapping("/manageDiscounts")
	@ApiOperation(value = "To get all the discounts")
	public List<DiscountsBO> getDiscounts() {
		return service.getDiscounts();
	}
}
