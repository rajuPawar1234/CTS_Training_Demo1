package com.flightbooking.kafka.producer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.support.SendResult;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;

@Service
@EnableKafka
public class PublisherService {
	@Autowired
	KafkaTemplate<String, String> kafkaTemplate;
	private Logger logger = LoggerFactory.getLogger(getClass());

	public void sendMessage(String flight) {
		logger.debug("_______________________________________________Inside send messgae----------" + flight);
		ListenableFuture<SendResult<String, String>> future = kafkaTemplate.send("flight_details", flight);

		future.addCallback(new ListenableFutureCallback<SendResult<String, String>>() {

			@Override
			public void onSuccess(SendResult<String, String> result) {
				System.out.println(
						"Sent message=[" + flight + "] with offset=[" + result.getRecordMetadata().offset() + "]");
			}

			@Override
			public void onFailure(Throwable ex) {
				System.out.println("Unable to send message=[" + flight + "] due to : " + ex.getMessage());
			}
		});
	}

}
