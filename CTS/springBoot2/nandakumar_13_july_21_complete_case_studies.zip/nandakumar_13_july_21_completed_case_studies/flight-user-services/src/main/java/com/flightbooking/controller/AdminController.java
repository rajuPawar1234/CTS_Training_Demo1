package com.flightbooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flightbooking.kafka.producer.PublisherService;
import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.FlightsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.ScheduleFlightBO;

import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@RequestMapping("/admin")
@CrossOrigin
@Secured("ROLE_ADMIN")
@ApiOperation(value = "Admin controller which is used to process the admin related process", notes = "It is secured for admin role")
public class AdminController {

	@Autowired
	private RestTemplate restTemplate;
	@Value("${admin.service.name}")
	private String serverUrl;

	@Autowired
	HttpHeaders httpHeaders;

	@Autowired
	PublisherService kafkaService;

	@GetMapping("/manageFlights")
	@ApiOperation(value = "To get all the flights that are active")
	public List<FlightsBO> getAllFlights() {

		List<FlightsBO> flights = null;
		ResponseEntity<List<FlightsBO>> response = restTemplate.exchange(serverUrl.concat("get-flights"),
				HttpMethod.GET, null, new ParameterizedTypeReference<List<FlightsBO>>() {
				});

		if (response != null) {
			if (response.getStatusCode() == HttpStatus.OK) {
				flights = response.getBody();
			}
		}

		return flights;

	}

	@PostMapping("/manageFlights")
	@ApiOperation(value = "To create a flights")
	public int createNewFlight(@ApiParam(value = "The flights details") @RequestBody FlightsBO flight) {
//		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
//		HttpEntity<FlightsBO> entity = new HttpEntity<FlightsBO>(flight, httpHeaders);
//		Integer response = restTemplate.postForObject(serverUrl.concat("create-flight"), entity, Integer.class);
//
//		return response;

		String message = "";
		try {
			message = new ObjectMapper().writeValueAsString(flight);
		} catch (JsonProcessingException e) {
			return 0;
		}
		kafkaService.sendMessage(message);
		return 1;
	}

	@PutMapping("/manageFlights/{id}")
	@ApiOperation(value = "To update the flights")
	public int updateFlight(@ApiParam(value = "The id which is used to update the flights") @PathVariable Long id,
			@ApiParam(value = "The flights details to update") @RequestBody FlightsBO flight) {
		flight.setId(id);
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<FlightsBO> entity = new HttpEntity<FlightsBO>(flight, httpHeaders);
		Integer response = restTemplate.postForObject(serverUrl.concat("update-flight"), entity, Integer.class);

		return response;
	}

	@DeleteMapping("/manageFlights/{id}")
	@ApiOperation(value = "To delete the flight")
	public int deleteFlight(@ApiParam(value = "The id to delete the flights") @PathVariable Long id) {
		System.out.println("###########Id:::::" + id);
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Long> entity = new HttpEntity<Long>(id, httpHeaders);
		Integer response = restTemplate.postForObject(serverUrl.concat("delete-flight"), entity, Integer.class);

		return response;
	}

	@GetMapping("/manageDiscounts")
	@ApiOperation(value = "To get all the discounts that are active")
	public List<DiscountsBO> getAllDiscounts() {
		List<DiscountsBO> discounts = null;
		ResponseEntity<List<DiscountsBO>> response = restTemplate.exchange(serverUrl.concat("get-discounts"),
				HttpMethod.GET, null, new ParameterizedTypeReference<List<DiscountsBO>>() {
				});

		if (response != null) {
			if (response.getStatusCode() == HttpStatus.OK) {
				discounts = response.getBody();
			}
		}

		return discounts;
	}

	@PostMapping("/manageDiscounts")
	@ApiOperation(value = "To create a discount")
	public int createNewDiscount(@ApiParam(value = "The discount details") @RequestBody DiscountsBO discount) {
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<DiscountsBO> entity = new HttpEntity<DiscountsBO>(discount, httpHeaders);
		Integer response = restTemplate.postForObject(serverUrl.concat("create-discount"), entity, Integer.class);

		return response;
	}

	@PutMapping("/manageDiscounts/{id}")
	@ApiOperation(value = "To update the discount")
	public int updateDiscount(@ApiParam(value = "The id which is used to update the discount") @PathVariable Long id,
			@ApiParam(value = "The discount details to update") @RequestBody DiscountsBO discount) {
		discount.setId(id);
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<DiscountsBO> entity = new HttpEntity<DiscountsBO>(discount, httpHeaders);
		Integer response = restTemplate.postForObject(serverUrl.concat("update-discount"), entity, Integer.class);

		return response;
	}

	@DeleteMapping("/manageDiscounts/{id}")
	@ApiOperation(value = "To delete the discount")
	public int deleteDiscount(@ApiParam(value = "The id to delete the discount") @PathVariable(value = "id") Long id) {
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Long> entity = new HttpEntity<Long>(id, httpHeaders);
		Integer response = restTemplate.postForObject(serverUrl.concat("delete-discount"), entity, Integer.class);

		return response;

	}

	@GetMapping("/scheduled-flights")
	@ApiOperation(value = "To get all the scheduled flights that are active")
	public List<ScheduleFlightBO> getAllSchedules() {
		List<ScheduleFlightBO> scheduledFlights = null;
		ResponseEntity<List<ScheduleFlightBO>> response = restTemplate.exchange(serverUrl.concat("get-schedules"),
				HttpMethod.GET, null, new ParameterizedTypeReference<List<ScheduleFlightBO>>() {
				});

		if (response != null) {
			if (response.getStatusCode() == HttpStatus.OK) {
				scheduledFlights = response.getBody();
			}
		}

		return scheduledFlights;
	}

	@PostMapping("/scheduled-flights")
	@ApiOperation(value = "To create a flights")
	public int createNewSchedule(
			@ApiParam(value = "The scheduled flights details for add") @RequestBody ScheduleFlightBO schedule) {
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<ScheduleFlightBO> entity = new HttpEntity<ScheduleFlightBO>(schedule, httpHeaders);
		Integer response = restTemplate.postForObject(serverUrl.concat("create-schedule"), entity, Integer.class);

		return response;
	}

	@PutMapping("/scheduled-flights/{id}")
	@ApiOperation(value = "To update the scheduled flight")
	public int updateSchedule(
			@ApiParam(value = "The id which is used to update the scheduled flight") @PathVariable Long id,
			@ApiParam(value = "The scheduled flights details to update") @RequestBody ScheduleFlightBO schedule) {
		schedule.setId(id);
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<ScheduleFlightBO> entity = new HttpEntity<ScheduleFlightBO>(schedule, httpHeaders);
		Integer response = restTemplate.postForObject(serverUrl.concat("update-schedule"), entity, Integer.class);

		return response;
	}

	@DeleteMapping("/scheduled-flights/{id}")
	@ApiOperation(value = "To delete the scheduled flight")
	public int deleteSchedule(@ApiParam(value = "The id to scheduled delete the flights") @PathVariable Long id) {
		System.out.println("###########Id:::::" + id);
		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<Long> entity = new HttpEntity<Long>(id, httpHeaders);
		Integer response = restTemplate.postForObject(serverUrl.concat("delete-schedule"), entity, Integer.class);

		return response;
	}

	@GetMapping("/locations")
	@ApiOperation(value = "To get all the airport locations that are available")
	@Cacheable(value = "getAllLocations", unless = "#result==null")
	public List<LocationsBO> getAllLocations() {
		List<LocationsBO> locations = null;
		ResponseEntity<List<LocationsBO>> response = restTemplate.exchange(serverUrl.concat("get-locations"),
				HttpMethod.GET, null, new ParameterizedTypeReference<List<LocationsBO>>() {
				});

		if (response != null) {
			if (response.getStatusCode() == HttpStatus.OK) {
				locations = response.getBody();
			}
		}

		return locations;

	}

}
