package com.flightbooking;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.dao.DuplicateKeyException;

import com.flightbooking.db.UserRepository;
import com.flightbooking.exception.CustomException;
import com.flightbooking.model.BookingFlightsBO;
import com.flightbooking.model.UserBO;
import com.flightbooking.service.UserService;

@SpringBootTest
class FlightUserServicesApplicationTests {

	@Autowired
	private UserService service;

	@MockBean
	private UserRepository respository;

	@Test
	void toCheckTheGetAvailableFlightsMethodAreWorking() {
		BookingFlightsBO search = new BookingFlightsBO(1L, 2l, Date.valueOf(LocalDate.now()));
		List<BookingFlightsBO> flightsAvaliable = Stream.of(search, search, search, search, search)
				.collect(Collectors.toList());
		Mockito.when(respository.getAvailableFlights(search)).thenReturn(flightsAvaliable);

		List<BookingFlightsBO> getAllAvailableFlights = service.getAvailableFlights(search);
		Assertions.assertEquals(flightsAvaliable, getAllAvailableFlights);

	}

	@Test
	void getAvailableFlightsMethodShouldReturnCustomError() {
		Mockito.when(respository.getAvailableFlights(null)).thenThrow(new NullPointerException());

		Assertions.assertThrows(NullPointerException.class, () -> {
			service.getAvailableFlights(null);
		});

	}

	@Test
	void toTestTheBookingFlights() throws CustomException {
		BookingFlightsBO bookingFlight = new BookingFlightsBO();
		bookingFlight.setScheduledId(1L);
		bookingFlight.setFromLocationId(1L);
		bookingFlight.setToLocationId(2L);
		bookingFlight.setUserName("nandakumar");
		bookingFlight.setPhoneNumber(9946590521L);
		bookingFlight.setTotalTickets(5);
		bookingFlight.setTotalprice(5000D);
		bookingFlight.setPricePerTickets(1000D);
		Mockito.when(respository.bookingFlights(bookingFlight)).thenReturn(1);
		int methodResult = service.bookingFlights(bookingFlight);

		Assertions.assertEquals(1, methodResult);

	}

	@Test
	void toTestTheBookingFlightsIfValueIsNull() throws CustomException {
		Mockito.when(respository.bookingFlights(null)).thenThrow(new NullPointerException());
		Assertions.assertThrows(NullPointerException.class, () -> {
			service.bookingFlights(null);
		});
	}

	@Test
	void toTestTheBookingFlightsIfUserIsInvalid() throws CustomException {
		BookingFlightsBO bookingFlight = new BookingFlightsBO();
		bookingFlight.setScheduledId(1L);
		bookingFlight.setFromLocationId(1L);
		bookingFlight.setToLocationId(2L);
		bookingFlight.setUserName("nandakumar");
		bookingFlight.setPhoneNumber(9946590521L);
		bookingFlight.setTotalTickets(5);
		bookingFlight.setTotalprice(5000D);
		bookingFlight.setPricePerTickets(1000D);
		Mockito.when(respository.bookingFlights(bookingFlight)).thenThrow(new CustomException());
		Assertions.assertThrows(CustomException.class, () -> {
			service.bookingFlights(bookingFlight);
		});
	}

	@Test
	void cancelBooking() throws CustomException {
		Mockito.when(respository.cancelBooking(1L)).thenReturn(1);
		Assertions.assertEquals(1, service.cancelBooking(1L));
	}

	@Test
	void cacelBookingIfIdIsNull() throws CustomException {
		Mockito.when(respository.cancelBooking(null)).thenThrow(new NullPointerException());
		Assertions.assertThrows(NullPointerException.class, () -> {
			service.cancelBooking(null);
		});

	}

	@Test
	void cacelBookingIfIdIsInvalid() throws CustomException {
		Mockito.when(respository.cancelBooking(5L)).thenThrow(new CustomException());
		Assertions.assertThrows(CustomException.class, () -> {
			service.cancelBooking(5L);
		});

	}

	@Test
	void signUp() throws CustomException {
		UserBO user = new UserBO();
		user.setUserName("Nandakumar");
		user.setPassword("Nandhu");
		Mockito.when(respository.signup(user)).thenReturn(1);
		Assertions.assertEquals(1, service.signup(user));
	}

	@Test
	void signUpWithNull() throws CustomException {
		Mockito.when(respository.signup(null)).thenThrow(NullPointerException.class);
		Assertions.assertThrows(NullPointerException.class, () -> {
			service.signup(null);
		});

	}

	@Test
	void signUpWithDuplicateException() throws CustomException {
		UserBO user = new UserBO();
		user.setUserName("Nandakumar");
		user.setPassword("Nandhu");
		Mockito.when(respository.signup(user)).thenThrow(new DuplicateKeyException("duplicate key"));
		Assertions.assertThrows(DuplicateKeyException.class, () -> {
			service.signup(user);
		});
	}

}
