import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './modules/login/login.component';
import { SignupComponent } from './modules/signup/signup.component';

const routes: Routes = [
  {path:"login",component:LoginComponent},
  {path:"signup",component:SignupComponent},
  {path:"user",loadChildren: ()=>import('./modules/user/user.module').then(module => module.UserModule)},
  {path:"admin",loadChildren: ()=>import('./modules/admin/admin.module').then(module => module.AdminModule)},
  {path:"**",pathMatch:"full",redirectTo:"/login"}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
