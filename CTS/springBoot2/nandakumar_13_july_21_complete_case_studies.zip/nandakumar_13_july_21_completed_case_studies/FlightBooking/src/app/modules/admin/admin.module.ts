import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NavbarComponent } from './navbar/navbar.component';
import { ManageAirlinesComponent } from './manage-airlines/manage-airlines.component';
import { ManageDiscountsComponent } from './manage-discounts/manage-discounts.component';
import { ManageSchedulesComponent } from './manage-schedules/manage-schedules.component';
import { ReportsComponent } from './reports/reports.component';
import { RouterModule } from '@angular/router';
import { adminRouting } from './admin-routing';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';



@NgModule({
  declarations: [
    NavbarComponent,
    ManageAirlinesComponent,
    ManageDiscountsComponent,
    ManageSchedulesComponent,
    ReportsComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(adminRouting),
    ReactiveFormsModule,
    NgbModule,
    FontAwesomeModule,
    TableModule,
    ButtonModule
  ]
})
export class AdminModule { }
