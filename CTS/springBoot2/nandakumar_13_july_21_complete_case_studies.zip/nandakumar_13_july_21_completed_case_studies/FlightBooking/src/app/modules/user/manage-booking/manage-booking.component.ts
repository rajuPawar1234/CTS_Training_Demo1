import { Component, OnInit } from '@angular/core';
import { faEdit } from '@fortawesome/free-regular-svg-icons';
import { faTimes, faTrashAlt } from '@fortawesome/free-solid-svg-icons';
import jsPDF, { CellConfig, DocumentProperties } from 'jspdf';
import { ToastrService } from '../../services/toastr.service';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-manage-booking',
  templateUrl: './manage-booking.component.html',
  styleUrls: ['./manage-booking.component.css']
})
export class ManageBookingComponent implements OnInit
{
  rows: any = [];
  faEdit = faEdit;
  faTrashAlt = faTrashAlt;
  faTimes = faTimes;
  column = [{ prop: "pnrNumber", name: "PNR Number" }, { prop: "fromLocationName", name: "From Airport" }, { prop: "toLocationName", name: "To Airport" }, { prop: "flightName", name: "Flight Name" }, { prop: "departureDate", name: "Departure Date" }, { prop: "departureTime", name: "Departure Time" }, { prop: "arrivalTime", name: "Arrival Time" }, { prop: "pricePerTickets", name: "Price Per Person" }, { prop: "totalTickets", name: "Tickets Booked" }, { prop: "totalprice", name: "Total Spend" }, { prop: "status", name: "Status" }];

  constructor(private userService: UserService, private toast: ToastrService)
  {

  }

  ngOnInit(): void
  {
    this.getAllBookings();
  }


  private getAllBookings()
  {
    this.userService.getAllBookedFlightsDetails().subscribe(res =>
      {
        //console.log(res);
        if (res != undefined && res != null)
        {
        this.rows = [];
        Object.values(res).map((value: any) =>
        {
          //console.log(value);
          let departureDate = Date.parse(value["departureDate"]);
          let state = +value["state"];
          //console.log(departureDate);
          let todayDate = Date.now();

          if (departureDate > todayDate && state == 1)
          {
            value["editAndDelete"] = true;
          }

          else
          {

            value["editAndDelete"] = false;

          }

          this.rows.push(value);
        });
      }

    });
  }

  cancel(row: any)
  {
    this.userService.cancelBooking(row["id"]).subscribe((res: any) =>
    {
      if (res.ok)
      {
        if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
        {
          //console.log(res["body"])
          let errorResponse: any = res["body"];
          this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

        }
        else
        {

          this.toast.show('Booked Flight is successfully cancelled', { classname: 'bg-success text-light', delay: 5000, headertext: 'Booked flight is cancelled' });
          this.getAllBookings();
        }
      }

    });

  }

  download(row: any)
  {
    let header1: CellConfig[] = [{ name: "pnrNumber", prompt: "PNR Number", align: "left", padding: 0, width: 80 }, { name: "fromLocationName", prompt: "From", align: "left", padding: 0, width: 50 }, { name: "toLocationName", prompt: "To", align: "left", padding: 0, width: 50 }, { name: "flightName", prompt: "Flight Name", align: "left", padding: 0, width: 80 }];
    let header2: CellConfig[] = [{ name: "departureDate", prompt: "Departure Date", align: "left", padding: 0, width: 80 }, { name: "departureTime", prompt: "Departure Time", align: "left", padding: 0, width: 50 }, { name: "arrivalTime", prompt: "Arrival Time", align: "left", padding: 0, width: 50 }, { name: "totalTickets", prompt: "Tickets Booked", align: "left", padding: 0, width: 80 }]
    let row1 = [
      {
        pnrNumber: row["pnrNumber"],
        fromLocationName: row["fromLocationName"],
        toLocationName: row["toLocationName"],
        flightName: row["flightName"]
      }
    ];
    let row2 = [
      {
        departureDate: row["departureDate"],
        departureTime: row["departureTime"],
        arrivalTime: row["arrivalTime"],
        totalTickets: row["totalTickets"] + ""
      }
    ];

    var exportPdfDoc = new jsPDF('l', 'mm', 'a5');
    exportPdfDoc.text("Downloaded Date :  " + new Date().toLocaleDateString(), 9, 10);
    exportPdfDoc.text("Name        :  " + row["userName"], 9, 19);
    exportPdfDoc.text("Mobile No :  " + row["phoneNumber"], 9, 25);
    let fileProp: DocumentProperties = {
      title: "Airline Ticket",
      author: "Flight Booking Application",
      subject: "This airline ticket is computer generated and the signature is not needed"
    }
    exportPdfDoc.setProperties(fileProp);
    exportPdfDoc.table(8, 30, row1, header1, {
      margins: 10,
      autoSize: false,
      printHeaders: true
    });
    exportPdfDoc.table(8, 55, row2, header2, {
      margins: 10,
      autoSize: false,
      printHeaders: true
    });

    exportPdfDoc.text("NET AMOUNT PAID :  Rs " + row["totalprice"], 9, 85);
    exportPdfDoc.save("Airline Ticket" + row["departureDate"] + "  " + Date.now() + ".pdf")
  }
}
