import { AdminRouting } from './admin-routing';

describe('AdminRouting', () => {
  it('should create an instance', () => {
    expect(new AdminRouting()).toBeTruthy();
  });
});
