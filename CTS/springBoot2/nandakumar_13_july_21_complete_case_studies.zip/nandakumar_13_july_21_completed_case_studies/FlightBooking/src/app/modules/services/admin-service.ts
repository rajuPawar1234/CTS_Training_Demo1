import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminService
{

  HOST: String = environment.host;
  PORT: number = environment.port;
  CONTEXT_PATH: String = environment.contextPath;
  SERVER_URL: String;
  httpHeaders: HttpHeaders;
  constructor(private http: HttpClient)
  {
    this.SERVER_URL = this.HOST.concat(":").concat(this.PORT.toString()).concat("/");
    if (this.CONTEXT_PATH.length > 0)
    {
      this.SERVER_URL=this.SERVER_URL.concat(this.CONTEXT_PATH.toString()).concat("/");
    }
    this.SERVER_URL=this.SERVER_URL.concat("admin/");
    this.httpHeaders = new HttpHeaders();

  }

  getAllFlights()
  {
    this.setHeaders();
    return this.http.get(this.SERVER_URL.concat("manageFlights"), { headers: this.httpHeaders });
  }
  addFlight(formData: any)
  {
    this.setHeaders();
    return this.http.post(this.SERVER_URL.concat("manageFlights"), formData, { observe: 'response', headers: this.httpHeaders });
  }
  updateFlight(formData: any)
  {
    this.setHeaders();
    return this.http.put(this.SERVER_URL.concat("manageFlights/" + formData["id"]), formData, { observe: 'response', headers: this.httpHeaders });
  }
  deleteFlight(id: number)
  {
    this.setHeaders();
    return this.http.delete(this.SERVER_URL.concat("manageFlights/" + id), { observe: 'response', headers: this.httpHeaders });

  }

  deleteDiscount(id: number)
  {
    this.setHeaders();
    return this.http.delete(this.SERVER_URL.concat("manageDiscounts/" + id), { observe: 'response', headers: this.httpHeaders });
  }
  addDiscount(formData: any)
  {
    this.setHeaders();
    return this.http.post(this.SERVER_URL.concat("manageDiscounts"), formData, { observe: 'response', headers: this.httpHeaders });
  }
  updateDiscount(formData: any)
  {
    this.setHeaders();
    return this.http.put(this.SERVER_URL.concat("manageDiscounts/" + formData["id"]), formData, { observe: 'response', headers: this.httpHeaders });
  }
  getAllDiscounts()
  {
    this.setHeaders();
    return this.http.get(this.SERVER_URL.concat("manageDiscounts"), { headers: this.httpHeaders });
  }
  getAllLocationsOfAirports()
  {
    this.setHeaders();
    return this.http.get(this.SERVER_URL.concat("locations"), { headers: this.httpHeaders });
  }
  scheduleFlight(formData: any)
  {
    this.setHeaders();
    return this.http.post(this.SERVER_URL.concat("scheduled-flights"), formData, { observe: 'response', headers: this.httpHeaders });
  }
  updateScheduledFlight(formData: any)
  {
    this.setHeaders();
    return this.http.put(this.SERVER_URL.concat("scheduled-flights/" + formData["id"]), formData, { observe: 'response', headers: this.httpHeaders });
  }
  deleteScheduledFlight(id: any)
  {
    this.setHeaders();
    return this.http.delete(this.SERVER_URL.concat("scheduled-flights/" + id), { observe: 'response', headers: this.httpHeaders });
  }


  getScheduledFlight()
  {
    this.setHeaders();
    return this.http.get(this.SERVER_URL.concat("scheduled-flights"), { headers: this.httpHeaders });
  }
  setHeaders()
  {
    let token = localStorage.getItem("Token");
    if (token != null)
      this.httpHeaders = this.httpHeaders.set("Authorization", token);
  }

}
