import { Routes } from "@angular/router";
import { UserGuard } from "../guards/user.guard";
import { BookingHistoryComponent } from "./booking-history/booking-history.component";
import { BookingComponent } from "./booking/booking.component";
import { ManageBookingComponent } from "./manage-booking/manage-booking.component";

export const userRoutes: Routes = [
    {path:"booking", component:BookingComponent,canActivate:[UserGuard]},
    {path:"manage-booking", component:ManageBookingComponent,canActivate:[UserGuard]},
    {path:"booking-history", component:BookingHistoryComponent,canActivate:[UserGuard]},
    {path:"**",pathMatch:"full",redirectTo:"booking"}
];