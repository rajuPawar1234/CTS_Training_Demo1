import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookingComponent } from './booking/booking.component';
import { ManageBookingComponent } from './manage-booking/manage-booking.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';
import { NavbarComponent } from './navbar/navbar.component';
import { RouterModule } from '@angular/router';
import {userRoutes} from "./user-routing";
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import {TableModule} from 'primeng/table';
import {ButtonModule} from 'primeng/button';

@NgModule({
  declarations: [
    BookingComponent,
    ManageBookingComponent,
    BookingHistoryComponent,
    NavbarComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(userRoutes),
    NgxDatatableModule,
    ReactiveFormsModule,
    NgbModule,
    FontAwesomeModule,
    TableModule,
    ButtonModule
    //PrimeIcons
  ]
})
export class UserModule { }
