import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AdminService } from '../../services/admin-service';
import { ToastrService } from '../../services/toastr.service';

@Component({
  selector: 'app-manage-discounts',
  templateUrl: './manage-discounts.component.html',
  styleUrls: ['./manage-discounts.component.css']
})
export class ManageDiscountsComponent implements OnInit
{

  faAdd = faPlus;
  rows: any = [];
  updateDiscountForm: FormGroup;
  addingDiscountForm: FormGroup;
  column = [{ name: "discountName", title: "discount Name" }, { name: "discountsNo", title: "Number" }, { name: "percentage", title: "Percentage" }, { name: "amount", title: "Maximum Amount" }];
  constructor(private formBuilder: FormBuilder, private service: AdminService, private modalService: NgbModal, private toast: ToastrService)
  {
    this.updateDiscountForm = this.formBuilder.group({
      discountName: ['', Validators.required],
      discountsNo: ['', Validators.required],
      percentage: [[Validators.required]],
      amount: [[Validators.required]],
      id: ['', [Validators.required]]
    });
    this.addingDiscountForm = this.formBuilder.group({
      discountName: ['', Validators.required],
      discountsNo: ['', Validators.required],
      percentage: [[Validators.required]],
      amount: [[Validators.required]]
    });
  }

  ngOnInit(): void
  {

    this.getAllDiscounts();
  }

  delete(rowData: any)
  {
    let id: number = rowData["id"];
    this.service.deleteDiscount(id).subscribe((res: any) =>
    {
      console.log(res);
      if (res.ok)
      {
        if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
        {
          //console.log(res["body"])
          let errorResponse: any = res["body"];
          this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

        }
        else
        {

          this.toast.show('Discount is deleted', { classname: 'bg-success text-light', delay: 5000, headertext: 'Delete Discount' });
          this.modalService.dismissAll();
          this.getAllDiscounts();
        }
      }
    });

  }
  showAddForm(content: any)
  {
    this.modalService.open(content, { centered: true, backdrop: 'static' });

  }
  showUpdateForm(content: any, row: any)
  {
    console.log(row)
    this.updateDiscountForm.setValue(row);
    this.modalService.open(content, { centered: true, backdrop: 'static' });

  }

  addDiscount()
  {
    console.log(this.addingDiscountForm)
    if (this.addingDiscountForm.valid)
    {
      let formData = this.addingDiscountForm.value;
      console.log(formData);
      this.service.addDiscount(formData).subscribe((res: any) =>
      {
        console.log(res);
        if (res.ok)
        {
          if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
          {
            //console.log(res["body"])
            let errorResponse: any = res["body"];
            this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

          }
          else
          {

            this.toast.show('Discounts is successfully created', { classname: 'bg-success text-light', delay: 5000, headertext: 'Create Discounts' });
            this.modalService.dismissAll();
            this.getAllDiscounts();
            this.addingDiscountForm.reset();
          }
        }
      });

    }

  }

  updateDiscount()
  {
    console.log(this.updateDiscountForm);

    if (this.updateDiscountForm.valid)
    {
      let formData = this.updateDiscountForm.value;
      this.service.updateDiscount(formData).subscribe((res: any) =>
      {
        console.log(res);
        if (res.ok)
        {
          if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
          {
            //console.log(res["body"])
            let errorResponse: any = res["body"];
            this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

          }
          else
          {

            this.toast.show('Discounts is updated', { classname: 'bg-success text-light', delay: 5000, headertext: 'Update Discounts' });
            this.modalService.dismissAll();
            this.getAllDiscounts();
            this.updateDiscountForm.reset();
          }
        }
      });


    }
  }

  getAllDiscounts()
  {
    this.rows = [];
    this.service.getAllDiscounts().subscribe(res =>
    {
      console.log(res)
      if (res != undefined && res != null)
      {
        Object.values(res).map((value: any) =>
        {

          this.rows.push(value);


        });
      }
      console.log(this.rows);
      // this.oneWayRows= Array.arguments(res);
    });
  }
}
