import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { faPlus } from '@fortawesome/free-solid-svg-icons';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AdminService } from '../../services/admin-service';
import { ToastrService } from '../../services/toastr.service';

@Component({
  selector: 'app-manage-schedules',
  templateUrl: './manage-schedules.component.html',
  styleUrls: ['./manage-schedules.component.css']
})
export class ManageSchedulesComponent implements OnInit
{
  flights: any = [];
  locations: any = [];
  updateScheduleFlightForm: FormGroup;
  scheduleFlightForm: FormGroup;
  invalidLocationAddForm: boolean = false;
  invalidDateAddForm: boolean = false;
  invalidDateUpdateForm: boolean = false;
  invalidTimeAddForm: boolean = false;
  invalidTimeUpdateForm: boolean = false;
  invalidLocationUpdateForm: boolean = false;
  minDate: any = "";
  minTime: any = "";
  faAdd = faPlus;
  rows: any = [];
  column = [{ name: "flightName", title: "Flight Name" }, { name: "fromLocationName", title: "From Location" }, { name: "toLocationName", title: "To Location" }, { name: "departureDate", title: "Departure Date" }, { name: "departureTime", title: "Departure Time" }, { name: "arrivalDate", title: "Arrival Date" }, { name: "arrivalTime", title: "Arrival Time" }, { name: "price", title: "Price/Seats" }];
  constructor(private formBuilder: FormBuilder, private service: AdminService, private modalService: NgbModal, private toast: ToastrService, private datePipe: DatePipe)
  {
    this.minDate = this.datePipe.transform(Date.now(), "YYYY-MM-dd");
    this.minTime = this.datePipe.transform(Date.now(), "HH:mm");
    this.updateScheduleFlightForm = this.formBuilder.group({
      flightId: ['', Validators.required],
      fromLocationId: ['', Validators.required],
      toLocationId: ["", [Validators.required]],
      price: ["", [Validators.required, Validators.min]],
      departureDate: ["", [Validators.required]],
      departureTime: ["", [Validators.required]],
      arrivalDate: ["", [Validators.required]],
      arrivalTime: ["", [Validators.required]],
      id: ['', [Validators.required]]
    });
    this.scheduleFlightForm = this.formBuilder.group({
      flightId: ['', Validators.required],
      fromLocationId: ['', Validators.required],
      toLocationId: ["", [Validators.required]],
      price: ["1", [Validators.required, Validators.min]],
      departureDate: ["", [Validators.required]],
      departureTime: ["", [Validators.required]],
      arrivalTime: ["", [Validators.required]],
      arrivalDate: ["", [Validators.required]]
    });
  }

  ngOnInit(): void
  {
    this.getAllFlights();
    this.getAllLocationsOfAirports();
    this.getScheduledFlight();
  }

  getAllFlights()
  {
    this.flights = [];
    this.service.getAllFlights().subscribe(res =>
    {
      console.log(res)
      if (res != undefined && res != null)
      {
        Object.values(res).map((value: any) =>
        {

          this.flights.push(value);


        });
      }
      console.log(this.flights);
      // this.oneWayRows= Array.arguments(res);
    });
  }

  getAllLocationsOfAirports()
  {
    this.locations = []
    this.service.getAllLocationsOfAirports().subscribe(res =>
    {
      console.log(res)
      if (res != undefined && res != null)
      {
        Object.values(res).map((value: any) =>
        {

          this.locations.push(value);


        });
      }
      console.log(this.locations);
      // this.oneWayRows= Array.arguments(res);
    });
  }

  showAddForm(content: any)
  {
    this.modalService.open(content, { centered: true, backdrop: 'static' });

  }
  showUpdateForm(content: any, row: any)
  {

    this.updateScheduleFlightForm.patchValue(row);
    this.modalService.open(content, { centered: true, backdrop: 'static' });

  }
  updateSchedule()
  {
    if (this.updateScheduleFlightForm.valid)
    {
      let formData = this.updateScheduleFlightForm.value;
      this.invalidDateUpdateForm = false;
      this.invalidTimeUpdateForm = false;
      let arrivalDateTime = new Date(formData["arrivalDate"] + " " + formData["arrivalTime"]);
      let departureDateTime = new Date(formData["departureDate"] + " " + formData["departureTime"]);
      console.log(departureDateTime);
      console.log(arrivalDateTime);
      if (new Date(formData["arrivalDate"]) >= new Date(formData["departureDate"]))
      {
        if (arrivalDateTime > departureDateTime)
        {

          if (+formData["fromLocationId"] != +formData["toLocationId"])
          {
            this.service.updateScheduledFlight(formData).subscribe((res: any) =>
            {
              console.log(res);
              if (res.ok)
              {
                if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
                {
                  //console.log(res["body"])
                  let errorResponse: any = res["body"];
                  this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

                }
                else
                {

                  this.toast.show('Flight scheduled is updated successfully', { classname: 'bg-success text-light', delay: 5000, headertext: 'Flight schedule updated' });
                  this.modalService.dismissAll();
                  this.getScheduledFlight();
                  this.updateScheduleFlightForm.reset();
                }
              }
            });
          }
          else
          {
            this.invalidLocationUpdateForm = true;
          }
        }
        else
        {
          this.invalidTimeUpdateForm = true;
          
        }
      }
      else
      {
        this.invalidDateUpdateForm = true;
        
      }
    }
  }
  addSchedule()
  {
    if (this.scheduleFlightForm.valid)
    {
      //console.log(this.scheduleFlightForm)
      let formData = this.scheduleFlightForm.value;
      let arrivalDateTime = new Date(formData["arrivalDate"] + " " + formData["arrivalTime"]);
      let departureDateTime = new Date(formData["departureDate"] + " " + formData["departureTime"]);
      formData["arrivalTime"] = formData["arrivalTime"] + ":00";
      formData["departureTime"] = formData["departureTime"] + ":00";
      console.log(formData);
      this.invalidDateAddForm = false;
      this.invalidLocationAddForm = false;
      this.invalidTimeAddForm = false;
      if (new Date(formData["arrivalDate"]) >= new Date(formData["departureDate"]))
      {
        if (arrivalDateTime > departureDateTime)
        {

          if (+formData["fromLocationId"] != +formData["toLocationId"])
          {


            this.service.scheduleFlight(formData).subscribe((res: any) =>
            {
              console.log(res);
              if (res.ok)
              {

                if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
                {
                  //console.log(res["body"])
                  let errorResponse: any = res["body"];
                  this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

                }
                else
                {

                  this.toast.show('Flight is scheduled successfully', { classname: 'bg-success text-light', delay: 5000, headertext: 'Flight schedule' });
                  this.modalService.dismissAll();
                  this.getScheduledFlight();
                  this.scheduleFlightForm.reset();
                }
              }
            });
          }
          else
          {
            this.invalidLocationAddForm = false;
          }
        }
        else
        {
          this.invalidTimeAddForm = true;

        }
      }
      else
      {
        this.invalidDateAddForm = true;
      }
    }
  }
  delete(rowData: any)
  {
    if (rowData != null && rowData != undefined)
    {
      let id = rowData["id"];
      this.service.deleteScheduledFlight(id).subscribe((res: any) =>
      {
        console.log(res);
        if (res.ok)
        {

          if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
          {
            //console.log(res["body"])
            let errorResponse: any = res["body"];
            this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

          }

          else
          {

            this.toast.show('Flight scheduled is deleted successfully', { classname: 'bg-success text-light', delay: 5000, headertext: 'Flight schedule deleted' });
            this.modalService.dismissAll();
            this.getScheduledFlight()
          }
        }
      });
    }
  }

  getScheduledFlight()
  {
    this.rows = [];
    this.service.getScheduledFlight().subscribe(res =>
    {
      console.log(res)
      if (res != undefined && res != null)
      {
        Object.values(res).map((value: any) =>
        {

          this.rows.push(value);


        });
      }
      console.log(this.rows);
      // this.oneWayRows= Array.arguments(res);
    });

  }
}
