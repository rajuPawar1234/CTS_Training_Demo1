import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { User } from '../models/User';

@Injectable({
  providedIn: 'root'
})
export class UserService
{

  HOST: String = environment.host;
  PORT: number = environment.port;
  CONTEXT_PATH: String = environment.contextPath;
  SERVER_URL: String;
  httpHeaders: HttpHeaders;
  constructor(private http: HttpClient)
  {
    this.SERVER_URL = this.HOST.concat(":").concat(this.PORT.toString()).concat("/");
    if (this.CONTEXT_PATH.length > 0)
    {
      this.SERVER_URL = this.SERVER_URL.concat(this.CONTEXT_PATH.toString()).concat("/")
    }
    this.httpHeaders = new HttpHeaders();

  }

  userRegistration(user: User)
  {

    return this.http.post(this.SERVER_URL.concat("signup"), user, { observe: 'response' });
  }

  toCheckLoginIsValid(user: any)
  {

    return this.http.post(this.SERVER_URL.concat("authenticate"), user, { observe: 'response' });
  }

  getFlights(formData: any, isOneWay: boolean)
  {
    if (isOneWay)
    {

    }
    else
    {

    }

    return this.http.post(this.SERVER_URL.concat("get-flights"), formData, { headers: this.httpHeaders });
  }
  bookFlight(bookingDetails: any)
  {
    this.setHeaders();
    return this.http.post(this.SERVER_URL.concat("flight-booking"), bookingDetails, { observe: 'response', headers: this.httpHeaders });
  }

  getAllBookedFlightsDetails()
  {
    this.setHeaders();
    return this.http.get(this.SERVER_URL.concat("booked-flights"), { headers: this.httpHeaders });
  }

  cancelBooking(id: string)
  {
    console.log(this.SERVER_URL.concat("cancel-booking/").concat(id))
    this.setHeaders();
    return this.http.post(this.SERVER_URL.concat("cancel-booking/").concat(id),null, { observe: 'response', headers: this.httpHeaders });
  }

  getAllLocation()
  {
    this.setHeaders();
    return this.http.get(this.SERVER_URL.concat("locations"), { headers: this.httpHeaders });
  }
  getAllDiscounts()
  {
    this.setHeaders();
    return this.http.get(this.SERVER_URL.concat("manageDiscounts"), { headers: this.httpHeaders });
  }
  setHeaders()
  {
    let token = localStorage.getItem("Token");
    if (token != null)
      this.httpHeaders = this.httpHeaders.set("Authorization", token);
  }
}
