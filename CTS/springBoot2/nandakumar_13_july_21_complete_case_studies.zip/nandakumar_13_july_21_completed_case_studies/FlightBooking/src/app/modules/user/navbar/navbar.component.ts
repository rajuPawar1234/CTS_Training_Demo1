import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  navBarShow:boolean=false;
  activeNav:boolean=false;
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  navButton()
  {
    this.navBarShow=!this.navBarShow;
  }
  logout()
  {
    localStorage.removeItem("token");
    this.router.navigate(["/login"]);
  }
  changeActive(num:number)
  {
    
    if(num===1)
    {
      this.activeNav=false;
    }
    else{
      
      this.activeNav=true;
    }

  }

}
