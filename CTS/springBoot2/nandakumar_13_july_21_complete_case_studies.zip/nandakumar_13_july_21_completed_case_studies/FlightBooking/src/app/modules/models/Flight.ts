export class Flight
{
    constructor(public flightId:number,public flightName:String,public totalSeats:number,public priceForASeat:number=0,public departureTime:string="",public duration:string="",public arrivalTime:string=""){}
}