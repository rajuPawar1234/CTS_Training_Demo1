import { Routes } from "@angular/router"
import { AdminGuard } from "../guards/admin.guard"
import { ManageAirlinesComponent } from "./manage-airlines/manage-airlines.component"
import { ManageDiscountsComponent } from "./manage-discounts/manage-discounts.component"
import { ManageSchedulesComponent } from "./manage-schedules/manage-schedules.component"

export const adminRouting:Routes =[
    {path:"manage-airline",component:ManageAirlinesComponent,canActivate:[AdminGuard]},
    {path:"manage-discounts",component:ManageDiscountsComponent,canActivate:[AdminGuard]},
    {path:"manage-schedule",component:ManageSchedulesComponent,canActivate:[AdminGuard]},
    {path:"**",pathMatch:"full",redirectTo:"manage-airline"}
]
