import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  activeNav:number=1;
  navBarShow:boolean=false;
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
  navButton()
  {
    this.navBarShow=!this.navBarShow;
  }
  logout()
  {
    localStorage.removeItem("token");
    this.router.navigate(["/login"]);
  }
  changeActive(num:number)
  {
    
    if(num===1)
    {
      this.activeNav=1;
    }
    else if(num==2){
      
      this.activeNav=2;
    }
    else{
      
      this.activeNav=3;
    }
  }

}
