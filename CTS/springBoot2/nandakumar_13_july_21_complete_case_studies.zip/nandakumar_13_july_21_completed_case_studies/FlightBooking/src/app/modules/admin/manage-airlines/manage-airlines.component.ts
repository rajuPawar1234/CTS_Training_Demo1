import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AdminService } from '../../services/admin-service';
import { ToastrService } from '../../services/toastr.service';
import { faPlus } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'app-manage-airlines',
  templateUrl: './manage-airlines.component.html',
  styleUrls: ['./manage-airlines.component.css']
})
export class ManageAirlinesComponent implements OnInit
{
  faAdd = faPlus;
  rows: any = [];
  updateFlightForm: FormGroup;
  addingFlightForm: FormGroup;
  column = [{ name: "flightName", title: "Flight Name" }, { name: "flightNo", title: "Number" }, { name: "numberOfSeats", title: "Total Seats" }, { name: "price", title: "Price/Seats" }];
  constructor(private formBuilder: FormBuilder, private service: AdminService, private modalService: NgbModal, private toast: ToastrService)
  {
    this.updateFlightForm = this.formBuilder.group({
      flightName: ['', Validators.required],
      flightNo: ['', Validators.required],
      numberOfSeats: [[Validators.required]],
      price: [[Validators.required]],
      id: ['', [Validators.required]]
    });
    this.addingFlightForm = this.formBuilder.group({
      flightName: ['', Validators.required],
      flightNo: ['', Validators.required],
      numberOfSeats: [[Validators.required]],
      price: [[Validators.required]]
    });
  }

  ngOnInit(): void
  {

    this.getAllFlights();
  }

  delete(rowData: any)
  {
    let id: number = rowData["id"];
    this.service.deleteFlight(id).subscribe((res: any) =>
    {
      console.log(res);
      if (res.ok)
      {
        if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
        {
          //console.log(res["body"])
          let errorResponse: any = res["body"];
          this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

        }
        else
        {

          this.toast.show('Flight is deleted', { classname: 'bg-success text-light', delay: 5000, headertext: 'Update flight' });
          this.modalService.dismissAll();
          this.getAllFlights();
        }
      }
    });

  }
  showAddForm(content: any)
  {
    this.modalService.open(content, { centered: true, backdrop: 'static' });

  }
  showUpdateForm(content: any, row: any)
  {
    console.log(row)
    this.updateFlightForm.setValue(row);
    this.modalService.open(content, { centered: true, backdrop: 'static' });

  }

  addFlight()
  {
    console.log(this.addingFlightForm)
    if (this.addingFlightForm.valid)
    {
      let formData = this.addingFlightForm.value;
      console.log(formData);
      this.service.addFlight(formData).subscribe((res: any) =>
      {
        console.log(res);
        if (res.ok)
        {

          if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
          {
            //console.log(res["body"])
            let errorResponse: any = res["body"];
            this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

          }
          else
          {
            this.toast.show('Flight is successfully created', { classname: 'bg-success text-light', delay: 5000, headertext: 'Create flight' });
            this.modalService.dismissAll();
            this.getAllFlights();
            this.addingFlightForm.reset();
          }

        }
      });

    }

  }

  updateFlight()
  {
    console.log(this.updateFlightForm);

    if (this.updateFlightForm.valid)
    {
      let formData = this.updateFlightForm.value;
      this.service.updateFlight(formData).subscribe((res: any) =>
      {
        console.log(res);
        if (res.ok)
        {

          if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
          {
            //console.log(res["body"])
            let errorResponse: any = res["body"];
            this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

          }
          else
          {

            this.toast.show('Flight is updated', { classname: 'bg-success text-light', delay: 5000, headertext: 'Update flight' });
            this.modalService.dismissAll();
            this.getAllFlights();
            this.updateFlightForm.reset();
          }
        }
      });


    }
  }

  getAllFlights()
  {
    this.rows = [];
    this.service.getAllFlights().subscribe(res =>
    {
      console.log(res)
      if (res != undefined && res != null)
      {
        Object.values(res).map((value: any) =>
        {

          this.rows.push(value);


        });
      }
      console.log(this.rows);
      // this.oneWayRows= Array.arguments(res);
    });
  }
}
