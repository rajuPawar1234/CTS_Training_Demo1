import { DatePipe } from '@angular/common';
import { Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ColumnMode, SelectionType } from '@swimlane/ngx-datatable';
import { ToastrService } from '../../services/toastr.service';
import { UserService } from '../../services/user.service';
@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class BookingComponent implements OnInit
{
  oneWayRows: any = [];
  numberOfTicket: number = 1;
  oneWaySelected = [];
  locations: any = [];
  discounts: any = [];
  fromLocationAndToLocationAreSame = false;
  @Input()
  totalPrice: number = 0;
  continueBookingButton = true;
  selectedAmount: number = 0;
  isOneWay: boolean = true;
  loadingIndicator = true;
  reorderable = true;
  isSearched = false;
  columns = [{ prop: "flightName", name: "Flight Name" }, { prop: "departureDate", name: "Departure Date" }, { prop: "departureTime", name: "Departure Time" }, { prop: "arrivalTime", name: "Arrival Time" }, { prop: "pricePerTickets", name: "Price/Seats" }];
  ColumnMode = ColumnMode;
  SelectionType = SelectionType;
  searchForm: FormGroup;
  continueBookingForm: FormGroup;
  twoWayRows = [];
  twoWaySelected = [];
  passengerNumberIsInValid: boolean = false;
  passengerNameIsInValid: boolean = false;
  minDate:any="";

  get f() { return this.searchForm.controls; }
  get g() { return this.continueBookingForm.controls; }
  constructor(private formBuilder: FormBuilder, private service: UserService, private modalService: NgbModal, private toast: ToastrService, private datePipe: DatePipe)
  {
    this.minDate = this.datePipe.transform(Date.now(), "YYYY-MM-dd");
    this.searchForm = this.formBuilder.group({
      fromLocationId: ['', Validators.required],
      toLocationId: ['', Validators.required],
      departureDate: ['', [Validators.required]],
      returnDate: [''],
    });
    this.continueBookingForm = this.formBuilder.group({
      passengerName: ['', Validators.required],
      passengerNumber: ['', Validators.required],
      numberOfTickets: [this.numberOfTicket, [Validators.required, Validators.max, Validators.min]],
      //totalPrice: ['',],
      discounts: [''],
    });
  }

  ngOnInit(): void
  {
    this.getAllLocation();
    this.getAllDiscounts();
  }
  onOneWaySelect(selected: any)
  {
    console.log(this.oneWaySelected);
    this.continueBookingButton = false;
  }
  onTwoWaySelect(selected: any)
  {
    this.continueBookingButton = false;
    console.log('Select Event', selected, this.twoWaySelected);
  }
  searchFlights()
  {
    console.log(this.searchForm);
    this.continueBookingButton = true;
    this.fromLocationAndToLocationAreSame = false;
    if (this.searchForm.valid)
    {
      this.oneWayRows = [];
      this.twoWayRows = [];
      let formData = this.searchForm.value;
      formData["fromLocationId"]=+formData["fromLocationId"];
      formData["toLocationId"]=+formData["toLocationId"];
      if (formData["fromLocationId"] != formData["toLocationId"])
      {

        if (this.isOneWay)
        {

          this.service.getFlights(formData, this.isOneWay).subscribe(res =>
          {
            console.log(res)
            if (res != undefined && res != null)
            {
              Object.values(res).map((value: any) =>
              {

                this.oneWayRows.push(value);
                this.oneWayRows = [...this.oneWayRows]
                this.isSearched = true;

              });
            }
            console.log(this.oneWayRows);
            if (this.oneWayRows.length == 0)
            {
              this.toast.show('Flights are not available for the selected date, please try with different date', { classname: 'bg-warning text-light', delay: 5000, headertext: 'Flight not available' });
            }

            // this.oneWayRows= Array.arguments(res);
          });
        }
        else
        {
          this.service.getFlights(formData, true).subscribe(res =>
          {
            this.oneWayRows = Array.arguments(res);
          });
          this.service.getFlights(formData, false).subscribe(res =>
          {
            this.twoWayRows = Array.arguments(res);
          });

        }
      }
      else
      {
        this.fromLocationAndToLocationAreSame = true;
      }
    }


  }
  tripChange(trip: number)
  {
    if (trip == 1)
    {
      this.isOneWay = true;
    }
    else
    {
      this.isOneWay = false;
    }

  }

  continueBooking(content: any)
  {
    this.numberOfTicket = 1;
    if (this.isOneWay)
    {
      if (this.oneWaySelected != null && this.oneWaySelected != undefined && this.oneWaySelected.length > 0)
      {

        this.selectedAmount = this.oneWaySelected[0]["pricePerTickets"];
      }
      else
      {

        this.selectedAmount = 0;
      }
      this.totalPrice = this.selectedAmount;
    }
    this.passengerNameIsInValid = false;
    this.passengerNumberIsInValid = false;
    this.modalService.open(content, { centered: true, backdrop: 'static' });
  }

  onChangeNumberOfTickets(value: number)
  {
    if (value > 0)
    {
      this.numberOfTicket = value;
      this.totalPrice = this.selectedAmount * this.numberOfTicket;

    }
    else
    {
      this.numberOfTicket = 0;
      this.totalPrice = 0;
    }
  }

  bookTheFlight()
  {
    let bookingDetails: any = {};
    let searchFormData = this.searchForm.value;
    console.log(this.continueBookingForm);
    if (this.continueBookingForm.valid)
    {
      let bookingFormData = this.continueBookingForm.value;
      let seletedOneWayFlightData = this.oneWaySelected[0];
      bookingDetails["userName"] = bookingFormData["passengerName"];
      bookingDetails["phoneNumber"] = bookingFormData["passengerNumber"];
      bookingDetails["totalTickets"] = bookingFormData["numberOfTickets"];
      bookingDetails["scheduledId"] = seletedOneWayFlightData["scheduledId"];
      bookingDetails["pricePerTickets"] = seletedOneWayFlightData["pricePerTickets"];
      bookingDetails["totalprice"] = this.totalPrice;
      bookingDetails["fromLocationId"] = +searchFormData["fromLocationId"];
      bookingDetails["toLocationId"] = +searchFormData["toLocationId"];
      console.log(bookingDetails);
      this.service.bookFlight(bookingDetails).subscribe((res: any) =>
      {
        console.log(res);
        if (res.ok)
        {
          if (res.body != null && res.body instanceof Object && res["statusCode"] != 200)
          {
            //console.log(res["body"])
            let errorResponse: any = res["body"];
            this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000, headertext: 'Sign Up Error' })

          }
          else
          {

            this.toast.show('Flight is successfully booked and you can manage the flights in Manage-Booking tab', { classname: 'bg-success text-light', delay: 5000, headertext: 'Booking flight' });
            this.modalService.dismissAll();
            this.isSearched = false;
            this.oneWayRows = [];
            this.oneWaySelected = [];
            this.twoWayRows = [];
            this.twoWaySelected = [];
            this.searchForm.reset();
            this.continueBookingForm.reset();
            this.isOneWay = true;
          }
        }
      });
    }
    else
    {
      if (this.continueBookingForm.controls["passengerName"].invalid)
      {
        this.passengerNameIsInValid = true;
      }
      if (this.continueBookingForm.controls["passengerNumber"].invalid)
      {

        this.passengerNumberIsInValid = true;
      }

    }
  }
  getAllLocation()
  {
    this.locations = [];
    this.service.getAllLocation().subscribe(res =>
    {
      console.log(res)
      if (res != undefined && res != null)
      {
        Object.values(res).map((value: any) =>
        {

          this.locations.push(value);



        });
      }
      console.log(this.locations);
      // this.oneWayRows= Array.arguments(res);
    });
  }
  getAllDiscounts()
  {
    this.discounts = [];
    this.service.getAllDiscounts().subscribe(res =>
    {
      console.log(res)
      if (res != undefined && res != null)
      {
        Object.values(res).map((value: any) =>
        {

          this.discounts.push(value);

        });
      }
      console.log(this.discounts);
      // this.oneWayRows= Array.arguments(res);
    });
  }

}
