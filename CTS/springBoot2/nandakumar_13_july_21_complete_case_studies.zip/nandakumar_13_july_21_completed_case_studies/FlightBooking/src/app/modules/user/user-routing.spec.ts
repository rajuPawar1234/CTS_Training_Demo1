import { UserRouting } from './user-routing';

describe('UserRouting', () => {
  it('should create an instance', () => {
    expect(new UserRouting()).toBeTruthy();
  });
});
