import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import jwtDecode from 'jwt-decode';
import { AdminService } from '../services/admin-service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit
{
  loginForm: FormGroup;
  invalidPassword: boolean = false;
  invalidEmail: boolean = false;
  invalidCredential: boolean = false;
  constructor(private router: Router, private service: UserService,private adminService:AdminService)
  {
    this.loginForm = new FormGroup({
      "email": new FormControl("", [Validators.required, Validators.email]),
      "password": new FormControl("", [Validators.required])
    });
  }

  ngOnInit(): void
  {
  }
  processLogin()
  {
    console.log(this.loginForm);
    if (this.loginForm.valid)
    {

      var email: String = this.loginForm.value["email"];
      var password: String = this.loginForm.value["password"];
      let user = {
        username: email,
        password: password
      }
      this.invalidCredential = false;
      this.invalidEmail = false;
      this.invalidPassword = false;
      this.service.toCheckLoginIsValid(user).subscribe(res =>
      {
        // console.log(res);
        if (res.ok)
        {
          let response = res.body;
          let isAdmin = false;
          if (response != null)
          {
            Object.values(response).map((value: string) =>
            {
              let decodedMessage = jwtDecode(value);
              console.log(decodedMessage)
              isAdmin = this.checkIsAdmin(decodedMessage);

              value = "Bearer ".concat(value);
              localStorage.setItem("Token", value);
            });

            if (isAdmin)
            {
              this.adminService.setHeaders();
              this.router.navigate(["/", "admin", "manage-airline"])
            }
            else
            {
              this.service.setHeaders();
              this.router.navigate(["/", "user", "booking"]);

            }
          }


        }
      }, err =>
      {
        localStorage.removeItem("Token");
        // console.log(err["message"])
        this.invalidCredential = true;
        this.invalidEmail = true;
        this.invalidPassword = true;
      });

      // if (email == "user@gmail.com" && password == "user")
      // {
      //   //console.log("inside")
      //   this.router.navigate(["/", "user", "booking"])
      // }
      // else if (email == "admin@gmail.com" && password == "admin")
      // {
      //   this.router.navigate(["/", "admin", "manage-airline"])

      // }

    }
    else
    {
      this.invalidEmail = false;
      this.invalidPassword = false;

      if (this.loginForm.controls["email"]["invalid"])
      {
        this.invalidEmail = true;
      }
      if (this.loginForm.controls["password"]["invalid"])
      {
        this.invalidPassword = true;
      }

    }

  }

  valueIsChanging(choice: number)
  {
    if (choice == 1)
    {
      this.invalidEmail = false;
    }
    else
    {
      this.invalidPassword = false;
    }
  }
  goToSignUp()
  {
    this.router.navigate(["/", "signup"])
  }

  checkIsAdmin(decodedToken: any)
  {
    return !!decodedToken["isAdmin"];
  }
}
