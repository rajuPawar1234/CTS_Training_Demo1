import { formatDate } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DatePipe } from '@angular/common';
import { User } from '../models/User';
import { UserService } from '../services/user.service';
import { ToastrService } from '../services/toastr.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit
{
  signupForm: FormGroup;
  invalidName: boolean = false;
  invalidPassword: boolean = false;
  invalidEmail: boolean = false;
  constructor(private router: Router,private service:UserService,private pipe:DatePipe,private toast:ToastrService)
  {
    this.signupForm = new FormGroup({
      "name": new FormControl("", [Validators.required]),
      "email": new FormControl("", [Validators.required, Validators.email]),
      "password": new FormControl("", [Validators.required])
    });
  }

  ngOnInit(): void
  {
  }
  processSignUp()
  {
    // console.log(this.signupForm);
    if (this.signupForm.valid)
    {
      
      var email: String = this.signupForm.value["email"];
      var password: String = this.signupForm.value["password"];
      var name: String = this.signupForm.value["name"];
      var joiningDate=this.pipe.transform( Date.now(),"YYYY-MM-dd");
      let user=new User(0,name,email,password,joiningDate!=null?joiningDate:"");
      // console.log(user);
      
      this.service.userRegistration(user).subscribe((res:any)=>{
        //console.log(res);
        if(res.ok)
        {
          if(res.body!=null&&res.body instanceof Object &&res["statusCode"]!=200)
          {
            //console.log(res["body"])
            let errorResponse:any=res["body"];
            this.toast.show(errorResponse["message"], { classname: 'bg-danger text-light', delay: 5000,headertext: 'Sign Up Error' })
            
          }
          else{
            this.toast.show('Sign-up process is completed successfully you can log-in by the email-id and password', { classname: 'bg-success text-light', delay: 5000,headertext: 'Sign Up Success' });
            this.signupForm.reset();
          }
          
        }
      },error=>{
        console.log(error);
      });


    }
    else
    {
      this.invalidEmail = false;
      this.invalidPassword = false;
      this.invalidName = false;

      if (this.signupForm.controls["name"]["invalid"])
      {
        this.invalidName = true;
      }
      if (this.signupForm.controls["email"]["invalid"])
      {
        this.invalidEmail = true;
      }
      if (this.signupForm.controls["password"]["invalid"])
      {
        this.invalidPassword = true;
      }

    }

  }

  valueIsChanging(choice: number)
  {
    if (choice == 1)
    {
      this.invalidEmail = false;
    }
    else if(choice==2)
    {
      this.invalidPassword = false;
    }
    else{
      this.invalidName=false;
    }
  }
  goToLogin()
  {
    this.router.navigate(["/", "login"])
  }

}
