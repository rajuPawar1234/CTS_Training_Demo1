export class User{
    constructor(public userId:Number,public userName:String,public mailId:String,public password:String,public joiningDate:String="",public isActive:number=1,public isAdmin=false){}
}