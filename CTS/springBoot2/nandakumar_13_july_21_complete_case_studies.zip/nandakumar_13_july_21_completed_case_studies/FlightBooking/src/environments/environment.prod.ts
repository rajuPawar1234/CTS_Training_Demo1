export const environment = {
  production: true,
  host:"http://ec2-35-170-80-234.compute-1.amazonaws.com",
  port:9090,
  contextPath:""
};
