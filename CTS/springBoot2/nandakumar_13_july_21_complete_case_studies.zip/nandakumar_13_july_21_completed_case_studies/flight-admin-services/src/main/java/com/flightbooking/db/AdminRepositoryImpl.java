package com.flightbooking.db;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.FlightsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.ScheduleFlightBO;

@Repository
public class AdminRepositoryImpl implements AdminRepository {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<FlightsBO> getAllFlights() {
		String queryForGettingAllFlights = "SELECT flight_id, flight_name, flight_no, number_of_seats, price FROM manage_flights where state=1";
		List<FlightsBO> flightDetails = jdbcTemplate.query(queryForGettingAllFlights, (rs, row) -> {
			FlightsBO flight = new FlightsBO();
			flight.setId(rs.getLong("flight_id"));
			flight.setFlightName(rs.getString("flight_name"));
			flight.setFlightNo(rs.getString("flight_no"));
			flight.setNumberOfSeats(rs.getInt("number_of_seats"));
			flight.setPrice(rs.getDouble("price"));
			return flight;
		});

		return flightDetails;
	}

	@Override
	public int createNewFlight(FlightsBO flight) {
		String queryForNewFlight = "INSERT INTO manage_flights (flight_name, flight_no, number_of_seats, price) VALUES(?, ?, ?,? )";
		int row = jdbcTemplate.update(queryForNewFlight, ps -> {
			ps.setString(1, flight.getFlightName());
			ps.setString(2, flight.getFlightNo());
			ps.setInt(3, flight.getNumberOfSeats());
			ps.setDouble(4, flight.getPrice());
		});
		return row;
	}

	@Override
	public int updateFlight(FlightsBO flight) {
		String queryForUpdateFlight = "UPDATE manage_flights SET flight_name=?, flight_no=?, number_of_seats=?, price=? WHERE flight_id=?";
		int row = jdbcTemplate.update(queryForUpdateFlight, ps -> {
			ps.setString(1, flight.getFlightName());
			ps.setString(2, flight.getFlightNo());
			ps.setInt(3, flight.getNumberOfSeats());
			ps.setDouble(4, flight.getPrice());
			ps.setLong(5, flight.getId());
		});
		return row;

	}

	@Override
	public int deleteFlight(Long id) {
		String queryFprDeleteTheFlight = "update manage_flights set state=0 where flight_id=?";
		int row = jdbcTemplate.update(queryFprDeleteTheFlight, ps -> {
			ps.setLong(1, id);
		});

		return row;
	}

	@Override
	public List<DiscountsBO> getAllDiscounts() {
		String queryForGettingDiscounts = "SELECT discount_id, discount_name, discounts_no, percentage, amount FROM manage_discounts where state=1";
		List<DiscountsBO> discountDetails = jdbcTemplate.query(queryForGettingDiscounts, (rs, row) -> {
			DiscountsBO discount = new DiscountsBO();
			discount.setId(rs.getLong("discount_id"));
			discount.setDiscountName(rs.getString("discount_name"));
			discount.setDiscountsNo(rs.getString("discounts_no"));
			discount.setPercentage(rs.getDouble("percentage"));
			discount.setAmount(rs.getDouble("amount"));
			return discount;
		});
		return discountDetails;
	}

	@Override
	public int createNewDiscount(DiscountsBO discount) {
		String queryForNewDiscount = "INSERT INTO manage_discounts (discount_name, discounts_no, percentage, amount) VALUES(?, ?, ?, ?)";
		int row = jdbcTemplate.update(queryForNewDiscount, ps -> {
			ps.setString(1, discount.getDiscountName());
			ps.setString(2, discount.getDiscountsNo());
			ps.setDouble(3, discount.getPercentage());
			ps.setDouble(4, discount.getAmount());
		});

		return row;
	}

	@Override
	public int updateDiscount(DiscountsBO discount) {
		String queryForUpdateDiscounts = "UPDATE manage_discounts SET discount_name=?, discounts_no=?, percentage=?, amount=? WHERE discount_id=?";
		int row = jdbcTemplate.update(queryForUpdateDiscounts, ps -> {
			ps.setString(1, discount.getDiscountName());
			ps.setString(2, discount.getDiscountsNo());
			ps.setDouble(3, discount.getPercentage());
			ps.setDouble(4, discount.getAmount());
			ps.setLong(5, discount.getId());
		});

		return row;
	}

	@Override
	public int deleteDiscount(Long id) {
		String queryFprDeleteTheFlight = "update manage_discounts set state=0 where discount_id=?";
		int row = jdbcTemplate.update(queryFprDeleteTheFlight, ps -> {
			ps.setLong(1, id);
		});

		return row;
	}

	@Override
	public List<ScheduleFlightBO> getAllSchedules() {
		String queryForGettingSchedules = "SELECT sf.scheduled_flight_id, sf.flight_id, mf.flight_name, sf.from_location_id, l.location_name as from_location_name, sf.to_location_id, l2.location_name as to_location_name, sf.price_per_tickets, sf.departure_date, sf.departure_time, sf.arrival_date, sf.arrival_time FROM scheduled_flights sf join locations l on l.id =sf.from_location_id join locations l2 on l2.id =sf.to_location_id join manage_flights mf on sf.flight_id=mf.flight_id where sf.state=1";
		List<ScheduleFlightBO> sheduledFlights = jdbcTemplate.query(queryForGettingSchedules, (rs, row) -> {
			ScheduleFlightBO flights = new ScheduleFlightBO();
			flights.setId(rs.getLong("scheduled_flight_id"));
			flights.setFlightId(rs.getLong("flight_id"));
			flights.setFlightName(rs.getString("flight_name"));
			flights.setFromLocationId(rs.getLong("from_location_id"));
			flights.setFromLocationName(rs.getString("from_location_name"));
			flights.setToLocationId(rs.getLong("to_location_id"));
			flights.setToLocationName(rs.getString("to_location_name"));
			flights.setPrice(rs.getDouble("price_per_tickets"));
			flights.setDepartureDate(rs.getDate("departure_date"));
			flights.setDepartureTime(rs.getTime("departure_time"));
			flights.setArrivalDate(rs.getDate("arrival_date"));
			flights.setArrivalTime(rs.getTime("arrival_time"));
			return flights;

		});
		return sheduledFlights;
	}

	@Override
	public int createNewSchedule(ScheduleFlightBO schedule) {
		String queryForCreateNewSchedule = "INSERT INTO scheduled_flights (flight_id, from_location_id, to_location_id, price_per_tickets, departure_date, departure_time, arrival_date, arrival_time) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
		int row = jdbcTemplate.update(queryForCreateNewSchedule, ps -> {
			ps.setLong(1, schedule.getFlightId());
			ps.setLong(2, schedule.getFromLocationId());
			ps.setLong(3, schedule.getToLocationId());
			ps.setDouble(4, schedule.getPrice());
			ps.setDate(5, schedule.getDepartureDate());
			ps.setTime(6, schedule.getDepartureTime());
			ps.setDate(7, schedule.getArrivalDate());
			ps.setTime(8, schedule.getArrivalTime());

		});
		return row;
	}

	@Override
	public int updateSchedule(ScheduleFlightBO schedule) {
		String queryForUpdateSchedule = "UPDATE scheduled_flights SET flight_id=?, from_location_id=?, to_location_id=?, price_per_tickets=?, departure_date=?, departure_time=?, arrival_date=?, arrival_time=? WHERE scheduled_flight_id=?";
		int row = jdbcTemplate.update(queryForUpdateSchedule, ps -> {
			ps.setLong(1, schedule.getFlightId());
			ps.setLong(2, schedule.getFromLocationId());
			ps.setLong(3, schedule.getToLocationId());
			ps.setDouble(4, schedule.getPrice());
			ps.setDate(5, schedule.getDepartureDate());
			ps.setTime(6, schedule.getDepartureTime());
			ps.setDate(7, schedule.getArrivalDate());
			ps.setTime(8, schedule.getArrivalTime());
			ps.setLong(9, schedule.getId());

		});
		return row;
	}

	@Override
	public int deleteSchedule(Long id) {
		String queryFprDeleteTheFlight = "update scheduled_flights set state=0 where scheduled_flight_id=?";
		int row = jdbcTemplate.update(queryFprDeleteTheFlight, ps -> {
			ps.setLong(1, id);
		});

		return row;
	}

	@Override
	public List<LocationsBO> getAllLocations() {
		String queryForGettingTheLocations = "SELECT id, location_name, location_code, location_code_no, address, latitude, longitude FROM locations";
		List<LocationsBO> locations = jdbcTemplate.query(queryForGettingTheLocations, (rs, row) -> {
			LocationsBO location = new LocationsBO();
			location.setId(rs.getLong("id"));
			location.setLocationName(rs.getString("location_name"));
			location.setLocationCode(rs.getString("location_code"));
			location.setLocationCodeNo(rs.getInt("location_code_no"));
			location.setAddress(rs.getString("address"));
			location.setLatitude(rs.getDouble("latitude"));
			location.setLongitude(rs.getDouble("longitude"));
			return location;
		});
		return locations;
	}
}
