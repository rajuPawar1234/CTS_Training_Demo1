package com.flightbooking.model;

import java.io.Serializable;

public class FlightsBO implements Serializable {

	private static final long serialVersionUID = 1540295591030204090L;
	private Long id;
	private String flightName;
	private String flightNo;
	private Integer numberOfSeats;
	private Double price;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public Integer getNumberOfSeats() {
		return numberOfSeats;
	}

	public void setNumberOfSeats(Integer numberOfSeats) {
		this.numberOfSeats = numberOfSeats;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("FlightsBO [id=");
		builder.append(id);
		builder.append(", flightName=");
		builder.append(flightName);
		builder.append(", flightNo=");
		builder.append(flightNo);
		builder.append(", numberOfSeats=");
		builder.append(numberOfSeats);
		builder.append(", price=");
		builder.append(price);
		builder.append("]");
		return builder.toString();
	}

}
