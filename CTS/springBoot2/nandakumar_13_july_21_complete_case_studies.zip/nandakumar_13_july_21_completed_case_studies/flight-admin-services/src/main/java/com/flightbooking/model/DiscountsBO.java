package com.flightbooking.model;

import java.io.Serializable;

public class DiscountsBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5112960222291309631L;
	private Long id;
	private String discountName;
	private String discountsNo;
	private Double percentage;
	private Double amount;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDiscountName() {
		return discountName;
	}

	public void setDiscountName(String discountName) {
		this.discountName = discountName;
	}

	public String getDiscountsNo() {
		return discountsNo;
	}

	public void setDiscountsNo(String discountsNo) {
		this.discountsNo = discountsNo;
	}

	public Double getPercentage() {
		return percentage;
	}

	public void setPercentage(Double percentage) {
		this.percentage = percentage;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DiscountsBO [id=");
		builder.append(id);
		builder.append(", discountName=");
		builder.append(discountName);
		builder.append(", discountsNo=");
		builder.append(discountsNo);
		builder.append(", percentage=");
		builder.append(percentage);
		builder.append(", amount=");
		builder.append(amount);
		builder.append("]");
		return builder.toString();
	}

}
