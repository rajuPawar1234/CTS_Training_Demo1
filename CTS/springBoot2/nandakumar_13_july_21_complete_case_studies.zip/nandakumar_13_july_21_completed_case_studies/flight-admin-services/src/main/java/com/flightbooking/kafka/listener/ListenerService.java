package com.flightbooking.kafka.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.flightbooking.model.FlightsBO;
import com.flightbooking.service.AdminService;

@Service
public class ListenerService {
	@Autowired
	AdminService service;
	private Logger logger = LoggerFactory.getLogger(getClass());

	@KafkaListener(topics = "flight_details", groupId = "mygroup")
	public void addFlightService(String message) {
		logger.info("Message is received" + message);
		FlightsBO flight = null;
		try {
			flight = new ObjectMapper().readValue(message, FlightsBO.class);
		} catch (JsonMappingException e) {

		} catch (JsonProcessingException e) {

		}

		if (flight != null) {
			service.createNewFlight(flight);
		}

	}
}
