package com.flightbooking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.stereotype.Service;

import com.flightbooking.db.AdminRepository;
import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.FlightsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.ScheduleFlightBO;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private AdminRepository repository;

	@Override
	public List<FlightsBO> getAllFlights() {

		return repository.getAllFlights();
	}

	@Override
	public int createNewFlight(FlightsBO flight) {

		return repository.createNewFlight(flight);
	}

	@Override
	public int updateFlight(FlightsBO flight) {

		return repository.updateFlight(flight);
	}

	@Override
	public List<DiscountsBO> getAllDiscounts() {
		return repository.getAllDiscounts();
	}

	@Override
	@CacheEvict(key = "manageDiscounts", allEntries = true)
	public int createNewDiscount(DiscountsBO discount) {
		return repository.createNewDiscount(discount);
	}

	@Override
	@CacheEvict(key = "manageDiscounts", allEntries = true)
	public int updateDiscount(DiscountsBO discount) {
		return repository.updateDiscount(discount);
	}

	@Override
	public List<ScheduleFlightBO> getAllSchedules() {
		return repository.getAllSchedules();
	}

	@Override
	public int createNewSchedule(ScheduleFlightBO schedule) {
		return repository.createNewSchedule(schedule);
	}

	@Override
	public int updateSchedule(ScheduleFlightBO schedule) {
		return repository.updateSchedule(schedule);
	}

	@Override
	public int deleteFlight(Long id) {

		return repository.deleteFlight(id);
	}

	@Override
	@CacheEvict(key = "manageDiscounts", allEntries = true)
	public int deleteDiscount(Long id) {
		return repository.deleteDiscount(id);
	}

	@Override
	public int deleteSchedule(Long id) {
		return repository.deleteSchedule(id);
	}

	@Override
	public List<LocationsBO> getAllLocations() {
		return repository.getAllLocations();
	}
}
