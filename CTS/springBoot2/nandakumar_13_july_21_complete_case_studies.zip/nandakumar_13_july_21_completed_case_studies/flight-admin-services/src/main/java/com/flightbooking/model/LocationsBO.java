package com.flightbooking.model;

import java.io.Serializable;

public class LocationsBO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6211208517630269171L;
	private Long id;
	private String locationName;
	private String locationCode;
	private Integer locationCodeNo;
	private String address;
	private Double latitude;
	private Double longitude;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public String getLocationCode() {
		return locationCode;
	}

	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}

	public Integer getLocationCodeNo() {
		return locationCodeNo;
	}

	public void setLocationCodeNo(Integer locationCodeNo) {
		this.locationCodeNo = locationCodeNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Double getLatitude() {
		return latitude;
	}

	public void setLatitude(Double latitude) {
		this.latitude = latitude;
	}

	public Double getLongitude() {
		return longitude;
	}

	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("LocationsBO [id=");
		builder.append(id);
		builder.append(", locationName=");
		builder.append(locationName);
		builder.append(", locationCode=");
		builder.append(locationCode);
		builder.append(", locationCodeNo=");
		builder.append(locationCodeNo);
		builder.append(", address=");
		builder.append(address);
		builder.append(", latitude=");
		builder.append(latitude);
		builder.append(", longitude=");
		builder.append(longitude);
		builder.append("]");
		return builder.toString();
	}

}
