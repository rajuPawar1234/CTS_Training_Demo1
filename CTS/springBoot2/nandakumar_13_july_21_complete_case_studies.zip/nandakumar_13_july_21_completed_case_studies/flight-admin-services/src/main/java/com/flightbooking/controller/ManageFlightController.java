package com.flightbooking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.FlightsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.ScheduleFlightBO;
import com.flightbooking.service.AdminService;

@RestController
@RequestMapping("/v1")
public class ManageFlightController {

	@Autowired
	private AdminService service;

	@GetMapping("/get-flights")
	public List<FlightsBO> getAllFlights() {
		return service.getAllFlights();
	}

	@PostMapping("/create-flight")
	public int createNewFlight(@RequestBody FlightsBO flight) {
		return service.createNewFlight(flight);
	}

	@PostMapping("/update-flight")
	public int updateFlight(@RequestBody FlightsBO flight) {
		return service.updateFlight(flight);
	}

	@PostMapping("/delete-flight")
	public int deleteFlight(@RequestBody Long id) {
		return service.deleteFlight(id);
	}

	@GetMapping("/get-discounts")
	public List<DiscountsBO> getAllDiscounts() {
		return service.getAllDiscounts();
	}

	@PostMapping("/create-discount")
	public int createNewDiscount(@RequestBody DiscountsBO discount) {
		return service.createNewDiscount(discount);
	}

	@PostMapping("/update-discount")
	public int updateDiscount(@RequestBody DiscountsBO discount) {
		return service.updateDiscount(discount);
	}

	@PostMapping("/delete-discount")
	public int deleteDiscount(@RequestBody Long id) {
		return service.deleteDiscount(id);
	}

	@GetMapping("/get-schedules")
	public List<ScheduleFlightBO> getAllSchedules() {
		return service.getAllSchedules();
	}

	@PostMapping("/create-schedule")
	public int createNewSchedule(@RequestBody ScheduleFlightBO schedule) {
		return service.createNewSchedule(schedule);
	}

	@PostMapping("/update-schedule")
	public int updateSchedule(@RequestBody ScheduleFlightBO schedule) {
		return service.updateSchedule(schedule);
	}

	@PostMapping("/delete-schedule")
	public int deleteSchedule(@RequestBody Long id) {
		return service.deleteSchedule(id);
	}
	
	@GetMapping("/get-locations")
	public List<LocationsBO> getAllLocations() {
		return service.getAllLocations();
	}
}
