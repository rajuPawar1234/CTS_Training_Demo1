package com.flightbooking.db;

import java.util.List;

import com.flightbooking.model.DiscountsBO;
import com.flightbooking.model.FlightsBO;
import com.flightbooking.model.LocationsBO;
import com.flightbooking.model.ScheduleFlightBO;

public interface AdminRepository {

	List<FlightsBO> getAllFlights();

	int createNewFlight(FlightsBO flight);

	int updateFlight(FlightsBO flight);

	List<DiscountsBO> getAllDiscounts();

	int createNewDiscount(DiscountsBO discount);

	int updateDiscount(DiscountsBO discount);

	List<ScheduleFlightBO> getAllSchedules();

	int createNewSchedule(ScheduleFlightBO schedule);

	int updateSchedule(ScheduleFlightBO schedule);

	int deleteFlight(Long id);

	int deleteDiscount(Long id);

	int deleteSchedule(Long id);

	List<LocationsBO> getAllLocations();

}
