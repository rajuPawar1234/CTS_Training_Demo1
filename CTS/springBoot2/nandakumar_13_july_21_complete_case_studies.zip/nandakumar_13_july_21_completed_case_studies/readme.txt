Database dumb query avaliable on the path nandakumar_13_july_21_completed_case_studies\flight-user-services\sql\flights.sql
**NOTE: before Import dumb should be create a database and name should be flights (databased name:flights)
username of database is root
password of database is root

you can change both of them on nandakumar_13_july_21_completed_case_studies\flight-user-services\src\main\resources\application.properties
and nandakumar_13_july_21_completed_case_studies\flight-admin-services\src\main\resources\application.properties

for example
spring.datasource.username=root
spring.datasource.password=root

In the database there is Default users 

admin based role user

username:admin@gmail.com
password:admin


user based role user
username:user@gmail.com
password:user

and also you can create users by clicking signup for user based roles but the admin based role cannot be created
